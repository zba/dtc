<?php
require_once('DtcAdminScriptingClient.php');

$login = $_GET['login'];

$sclient = new DtcAdminScriptingClient( 'dtc.codebase.local', 'dtc', 'belealld' );

$ret = $sclient->addNewAccountRequest( 1, $login, 'testpass', 'Mustername', 'Vorname', 'yes', 'Musterfirma AG', '1111', 'muster@example.com', 2222, 3333, 'Adresse1', 'Adresse2', 'Adresse3', 9999, 'Musterstadt', 'NA', 'Notizen');
$ret .= $sclient->confirmWaitingAccount( $login );

echo $ret;
