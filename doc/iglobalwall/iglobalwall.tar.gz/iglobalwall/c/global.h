typedef struct{
	char* mysql_hostname;
	char* mysql_user;
	char* mysql_pass;
	char* mysql_db;
	char* mysql_table_whitelist;
	char* mysql_table_pop_access;
}igw_config_t;
