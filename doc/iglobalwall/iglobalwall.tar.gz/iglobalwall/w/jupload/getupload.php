<?php

include("../inc/dtc_functions.php");
include("../inc/dbconnect.php");

if($_REQUEST["filename_value"]["name"] == "upload.cab" ||
$_REQUEST["filename_value"]["name"] == "getupload.php" ||
$_REQUEST["filename_value"]["name"] == "log" ||
$_REQUEST["filename_value"]["name"] == "upload.jar"){
	ob_start();
	print_r($_REQUEST);
	$plop = ob_get_contents();
	ob_end_flush();
	$fp=fopen("log","w");
	fwrite($fp,"Cannot upload this name: thisis my script files : $plop!");
	fclose($fp);
	die("Cannot upload this name: thisis my script files!");
}

$zemail = str_replace("#","@",$_REQUEST["mailbox"]);
if(!isValidEmail($zemail) ||
!isDTCPassword($_REQUEST["igw_login"]) ||
!isFtpLogin($_REQUEST["igw_pass"])){
	ob_start();
	print_r($_REQUEST);
	$plop = ob_get_contents();
	ob_end_flush();
	$fp=fopen("log","w");
	fwrite($fp,"Incorrect login or password format $plop!");
	fclose($fp);
	die("Incorrect login or password format!!");
}

$q = "SELECT * FROM users WHERE igw_login='".$_REQUEST["igw_login"]."' AND igw_pass='".$_REQUEST["igw_pass"]."';";
$r = mysql_query($q)or die("Cannot execute query: \"$q\" line".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
$n = mysql_num_rows($r);
if($n != 1){
	ob_start();
	print_r($_REQUEST);
	$plop = ob_get_contents();
	ob_end_flush();
	$fp=fopen("log","w");
	fwrite($fp,"Wrong login or password!!! $plop");
	fclose($fp);
	die("Wrong login or password!!!");
}


$filename = pathinfo($_REQUEST["filename_value"]["name"]);
$zefile = "/www/jupload/".$_REQUEST["igw_login"]."-".$zemail."-".$filename["basename"];
$err = move_uploaded_file($_REQUEST["filename_value"]["tmp_name"],$zefile);
if($err != false){
	$fp=fopen("log","w");
	fwrite($fp,"2Successfully upload ".$_REQUEST["filename_value"]["name"]." !\n");
	fclose($fp);
	echo "Successfully upload !<br>";
	// Read the file and test-out if it's a good format containing emails.
	$lines = file($zefile);

	$field_num = -1;
	$items = explode(";",$lines[0]);
	for($i=0;$i<sizeof($items);$i++){
		if($items[$i] == "E-mail Address"){
			$field_num = $i;
			break;
		}
	}
	if($field_num == -1){
		$fp=fopen("log","w");
		fwrite($fp,"Cannot find field \"E-mail Address\" in uploaded file!");
		fclose($fp);
		die();
	}
	for($i=1;$i<sizeof($lines);$i++){
		$zeLine = explode(";",$lines[$i]);
		$addr = $zeLine[$field_num];
		if(isValidEmail($addr)){
			$mail2add = explode('@',$addr);
			$mailuser2add = $mail2add[0];
			$maildomain2add = $mail2add[1];
			$q = "INSERT IGNORE INTO whitelist (igw_login,mail_from_user,mail_from_domain,mailbox) VALUES ('".$_REQUEST["igw_login"]."','$mailuser2add','$maildomain2add','$zemail');";
			$r = mysql_query($q)or die("Cannot execute query: \"$q\" line".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
			$fp=fopen("log","a+");
			fwrite($fp,"Query $q !\n");
			fclose($fp);
		}
	}

/*	ob_start();
 	print_r($csv);
	$plop = ob_get_contents();
	ob_end_flush();

	$fp=fopen("log","w");
	fwrite($fp,"File successfully read !\n".
	$plop."\n"
	);
	fclose($fp);
*/

//	unlink("/www/jupload/".$_REQUEST["filename_value"]["name"]);
}else{
	ob_start();
	print_r($_REQUEST);
	$plop = ob_get_contents();
	ob_end_flush();
	$fp=fopen("log","w");
	fwrite($fp,"Failed to upload $filename_value !\n".
	$plop."\n"
	);
	fclose($fp);
	echo "Failed to upload !<br>";
}

?>
