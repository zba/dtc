Database iglobalwall running on localhost
# phpMyAdmin MySQL-Dump
# version 2.2.3
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Generation Time: Apr 02, 2004 at 04:16 AM
# Server version: 3.23.49
# PHP Version: 4.1.2
# Database : 	globalwall#
--------------------------------------------------------

#
# Table structure for table ailbox#

CREATE TABLE mailbox (
  igw_login varchar(16) NOT NULL default '',
  pop3_server varchar(128) NOT NULL default '',
  pop3_login varchar(128) NOT NULL default '',
  pop3_pass varchar(128) NOT NULL default '',
  checkit enum('yes','no') NOT NULL default 'yes',
  PRIMARY KEY  (igw_login,pop3_server,pop3_login),
  UNIQUE KEY igw_login (igw_login,pop3_server,pop3_login),
  KEY igw_login_2 (igw_login)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table sers#

CREATE TABLE users (
  igw_login varchar(16) NOT NULL default '',
  igw_pass varchar(16) NOT NULL default '',
  full_name varchar(64) NOT NULL default '',
  remember_me enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (igw_login),
  UNIQUE KEY igw_login (igw_login),
  KEY igw_login_2 (igw_login)
) TYPE=MyISAM;
# --------------------------------------------------------

#
# Table structure for table hitelist#

CREATE TABLE whitelist (
  igw_login varchar(16) NOT NULL default '',
  mail_from varchar(128) NOT NULL default '',
  mailbox varchar(128) NOT NULL default '',
  PRIMARY KEY  (igw_login,mail_from,mailbox),
  UNIQUE KEY unicbox (igw_login,mail_from,mailbox),
  KEY igw_login (igw_login)
) TYPE=MyISAM;
