<?php

function pageTop(){
	global $PHP_SELF;
	global $rub;
	global $sousrub;
	global $lang;

	$txt_switch_langu_button = array(
		"fr" => "Switch to english",
		"en" => "Le site en fran�ais");
	$txt_switch = array(
		"fr" => "en",
		"en" => "fr");
	///////////////////////////////
	// LOGO + LANGUAGE SELECTION //
	///////////////////////////////
	$switch_lang = skin("button/green_on_blue",$txt_switch_langu_button[$lang],"$PHP_SELF?rub=$rub&sousrub=$sousrub&change_language=".$txt_switch[$lang]);

	$mnpath = "gfx/page_head/menu";
	$menu1 = makeImgRollover("$mnpath/home_n.gif","$mnpath/home_r.gif","Home page");
	$menu2 = makeImgRollover("$mnpath/services_n.gif","$mnpath/services_r.gif","Hosting services");
	$menu3 = makeImgRollover("$mnpath/tools_n.gif","$mnpath/tools_r.gif","Hosting tools");
	$menu4 = makeImgRollover("$mnpath/softwares_n.gif","$mnpath/softwares_r.gif","Free Software");
	$menu5 = makeImgRollover("$mnpath/about_us_n.gif","$mnpath/about_us_r.gif","About US");

	if($rub == "services"){
		$menu2 = "<img border=\"0\" src=\"$mnpath/services_s.gif\">";
	}else if($rub == "tools"){
		$menu3 = "<img border=\"0\" src=\"$mnpath/tools_s.gif\">";
	}else if($rub == "softwares"){
		$menu4 = "<img border=\"0\" src=\"$mnpath/softwares_s.gif\">";
	}else if($rub == "about"){
		$menu5 = "<img border=\"0\" src=\"$mnpath/about_us_s.gif\">";
	}else{
		$menu1 = "<img width=\"97\" height=\"48\" border=\"0\" src=\"$mnpath/home_s.gif\">";
	}

	$menu1 = "<a href=\"$PHP_SELF?\">$menu1</a>";
	$menu2 = "<a href=\"$PHP_SELF?rub=services\">$menu2</a>";
	$menu3 = "<a href=\"https://dtc.gplhost.com\">$menu3</a>";
	$menu4 = "<a href=\"$PHP_SELF?rub=softwares\">$menu4</a>";
	$menu5 = "<a href=\"$PHP_SELF?rub=about\">$menu5</a>";


	$menu = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="1">
<tr>
	<td width="1">'.$menu1.'</td>
	<td width="1">'.$menu2.'</td>
	<td width="1">'.$menu3.'</td>
	<td width="1">'.$menu4.'</td>
	<td width="1">'.$menu5.'</td>
	<td width="100%" background="'.$mnpath.'/back.gif">&nbsp;</td>
</tr></table>
';

	//////////////////////////
	// The logo and pagetop //
	//////////////////////////
	$page_top_logo = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="1">
<tr>
	<td width="1"><img width="72" height="72" src="gfx/page_head/title/topleft.gif"></td>
	<td width="1"><img width="346" height="72" src="gfx/page_head/title/gpl_host.gif"></td>
	<td width="1"><img height="72" src="gfx/page_head/title/gpl_cursor.gif"></td>
	<td width="100%" background="gfx/page_head/title/back.gif"></td>
</tr>
</table>
';

	$page_top_logo = '<a href="http://www.iglobalwall.com"><img border="0" src="gfx/logo.gif"></a>';

	///////////////////////////////////////////////
	// Layout the top logo and the menu together //
	///////////////////////////////////////////////
	$all_page_top = '<table  cellspacing="0" cellpadding="0" border="0" width="100%" height="1">
<tr>
	<td width="100%" height="1">'.$page_top_logo.'</td></tr>';
/*<tr>
	<td width="100%" height="1">'.$menu.'</td>
</tr>*/
	$all_page_top .= '</table>
';

	return $all_page_top;
}

?>
