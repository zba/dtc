<?php

function uploadObject($button_text,$sendvar_name,$url){
	$end_url = strstr($url,"?");
	$file_form = "<form action=\"$url\">";
	if($end_url != NULL){
		$start = substr($url,0,strlen($url)-strlen($end_url));
		$end = substr($end_url,1);
		$params = explode("\&",$end);
		for($i=0;$i<sizeof($params);$i++){
			$parm = $params[$i];
			$yow = explode("=",$params[$i]);
			$file_form .= "<input type=\"hidden\" name=\"".$yow[0]."\" value=\"".$yow[1]."\">";
		}
	}
	$file_form .= "<input type=\"file\" name=\"$sendvar_name\">";
	$file_form .= "<input type=\"submit\" value=\"$button_text\"></form>";

	$jv = "<script language=\"javascript\">

var je;	// java enable boolean
var is_ie;
var user_agent;
var jvm_microsoft;	// jvm = microsoft boolean
var jvm_start_objet;	// The applet returns us what was the object used to start the java code

user_agent = navigator.userAgent.toLowerCase();

if( navigator.javaEnabled() ) {
	// document.write('Java enabled...');
	je = true;

	if( user_agent.indexOf('msie') != -1 && user_agent.indexOf('opera') == -1){
		var flag=0;	// Set to one as soon as applet started
		document.write('<applet width=\"0\" height=\"0\" code=\"jvmdetector.class\" name=\"jvmdetect\" id=\"jvmdetect\" codebase=\".\" MAYSCRIPT SCRIPTABLE><param name=\"MAYSCRIPT\" value=\"true\"><param name=\"scriptable\" value=\"true\"></applet>');

		// This is a trick to wait until the applet is loaded.
		// Until we go to the catch, the applet is not ready, so we loop...
		// Note: a wait function should be added to release machine time.
		// A timeout should be set if java is not installed (case of some Windows XP)
		while(flag == 0){
			try{
				if(document.jvmdetect.canIcallYou() == 1)
					flag = 1;
			}catch(all){
			}
		}
		jvm_start_objet = document.jvmdetect.isJVMTypeMicrosoft();
		if(jvm_start_objet.indexOf('com.ms.applet.Bro') != -1){
			jvm_microsoft = true;
		}else{
			jvm_microsoft = false;
		}
	}else{
		jvm_microsoft = false;
	}
	if( jvm_microsoft == true){
		// Microsoft JVM and .cab stuff
		document.write('<applet width=\"100\" height=\"30\" code=\"upload.class\" codebase=\".\"><param name=\"cabbase\" value=\"upload.cab\"><param name=\"jupload_button_text\" value=\"".$button_text."\"><param name=\"jupload_file_varname\" value=\"".$sendvar_name."\"><param name=\"jupload_up_url\" value=\"".$url."&MAX_FILE_SIZE=200000\"></applet>');
	}else{
		// Sun or others JVM and .jar stuff
		document.write('<OBJECT classid = \"clsid:8AD9C840-044E-11D1-B3E9-00805F499D93\" codebase = \"http://java.sun.com/products/plugin/autodl/jinstall-1_4-windows-i586.cab#Version=1,4,0,0\" width= \"140\" height= \"32\"><param name=\"CODE\" value= \"upload.class\"><param name=\"CODEBASE\" value=\".\"><param name=\"ARCHIVE\" value=\"upload.jar\"><param name=\"type\" value=\"application/x-java-applet;version=1.4\"><param name=\"jupload_button_text\" value=\"".$button_text."\"><param name=\"jupload_file_varname\" value=\"".$sendvar_name."\"><param name=\"jupload_up_url\" value=\"".$url."&MAX_FILE_SIZE=100000000\"><COMMENT><EMBED type = \"application/x-java-applet;version=1.4\" CODE = \"upload.class\" JAVA_CODEBASE = \".\" ARCHIVE = \"upload.jar\" WIDTH = \"140\" HEIGHT = \"32\" pluginspage = \"http://java.sun.com/products/plugin/index.html#download\" jupload_button_text = \"".$button_text."\" jupload_file_varname = \"".$sendvar_name."\" jupload_up_url =\"".$url."&MAX_FILE_SIZE=100000000\"></EMBED></COMMENT></OBJECT>');
	}
}else{
	je = false;
	document.write('".$file_form."');
}

</script>
<noscript>$file_form</noscript>";

	return $jv;
}

// "http://www.iglobalwall.com/jupload/getupload.php?igw_login='.$user_info["igw_login"].'&igw_pass='.$user_info["igw_pass"].'
echo uploadObject("Upload CSV","filename_value","http://www.iglobalwall.com/jupload/getupload.php?test=toto");

?>