<?php

$leftCont = "<center><h1>This page is under construction!</h1></center>
<br><br><br>

<table width=\"100%\" height=\"100%\">
<tr>
	<td width=\"100%\" height=\"100%\" valign=\"center\"><center><a href=\"$PHP_SELF?\"><h2>Back to home page</h2></a></center></td>
</tr></td></table>";

$content = skin("green_gpl",$leftCont,"");

?>
