<?php

session_register("user_info");
if($_REQUEST["sousrub"] == "logout"){
        $user_info["loged_in"]=false;
        unset($user_info);
}
if(!isset($user_info)){
        $user_info["loged_in"]=false;
}
if($user_info["loged_in"] != true){
	if($_REQUEST["action"] == "login"){
		if(!isFtpLogin($_REQUEST["igw_login"]) || !isDTCPassword($_REQUEST["igw_pass"])) die("Parameters for login or password are not good !");
		$q = "SELECT * FROM $table_users WHERE igw_login='".$_REQUEST["igw_login"]."' AND igw_pass='".$_REQUEST["igw_pass"]."';";
		$r = mysql_query($q)or die("Could not execute $q in file: ".__FILE__." line:".__LINE__.": ".mysql_error());
		$n = mysql_num_rows($r);
		if($n == 1){
			$user_info["loged_in"]=true;
			$user_info["igw_login"]=$_REQUEST["igw_login"];
			$user_info["igw_pass"]=$_REQUEST["igw_pass"];
			if($_REQUEST["igw_remember"] == "yes"){
				setcookie ("iGWallLOGIN",$_REQUEST["igw_login"],time()+60*60*24*7,"/","www.iglobalwall.com",0);
				setcookie ("iGWallPASS",$_REQUEST["igw_pass"],time()+60*60*24*7,"/","www.iglobalwall.com",0);
			}
		}
	}
}

if($user_info["loged_in"]==true){

	$q = "SELECT * FROM $table_users WHERE igw_login='".$user_info["igw_login"]."' AND igw_pass='".$user_info["igw_pass"]."';";
	$r = mysql_query($q)or die("Could not execute $q in file: ".__FILE__." line:".__LINE__.": ".mysql_error());
	$n = mysql_num_rows($r);
	if($n != 1) die("Cannot find user when doing $q in file: ".__FILE__." line:".__LINE__.": ".mysql_error());
	$user_info["table_users"] = mysql_fetch_array($r);
	$user_info["table_mailbox"] = fetchAllRawsInArray("SELECT * FROM $table_mailbox WHERE igw_login='".$user_info["igw_login"]."' ORDER BY pop3_email;");
	$user_info["table_whitelist"] = fetchAllRawsInArray("SELECT * FROM $table_whitelist WHERE igw_login='".$user_info["igw_login"]."' ORDER BY mailbox,mail_from_user,mail_from_domain;");

	include("rubs/main.php");

}else{
	if($_REQUEST["sousrub"] == "logout"){
		setcookie("iGWallLOGIN","",time()+60*60*24*7,"/","www.iglobalwall.com",0);
		setcookie("iGWallPASS","",time()+60*60*24*7,"/","www.iglobalwall.com",0);
		$main_text = "<blockquote><center><h3>Loged out!</h3><br><br>
<b>You have been loged out: thanks for using iGlobalWall services</b><br><br>
<a href=\"$PHP_SELF\">Back to home page</a>
</center></blockquote>";
	}else{
		$main_text = "<blockquote><center><h3>Wrong login or password !</h3><br><br>
<b>403: Identification failed, or timeout expired.</b><br><br>
<a href=\"$PHP_SELF\">Try again</a> - <a href=\"$PHP_SELF?rub=register\">Register</a> - <a href=\"#\">Lost Password</a>
</center></blockquote>";
	}
	$content = skin("iglobal","$main_text","Identification failed");
}

?>