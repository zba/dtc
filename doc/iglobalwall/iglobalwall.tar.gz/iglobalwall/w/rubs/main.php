<?php

$MAX_SUBJECT_SMALL = 25;

function draw_left_menu($user_info){
	global $dtc_use_text_menu;
	$dtc_use_text_menu = "no";

	$user_menu[] = array (
		"text" => "my account",
		"type" => "link",
		"link" => "my account");

	$nbr_box = sizeof($user_info["table_mailbox"]);
	$submenu[] = array (
		"text" => "senders whitelist",
		"type" => "link",
		"link" => "senders whitelist");
	$submenu[] = array (
		"text" => "unverified emails",
		"type" => "link",
		"link" => "unverified emails");

	for($i=0;$i<$nbr_box;$i++){
		$mailboxname = $user_info["table_mailbox"][$i]["pop3_email"];
		$user_menu[] = array(
			"text" => $mailboxname,
			"type" => "menu",
			"link" => $mailboxname,
			"sub" => $submenu);
	}
	$user_menu[] = array (
		"text" => "add pop3 account",
		"type" => "link",
		"link" => "add pop3 account");
	$user_menu[] = array (
		"text" => "billing",
		"type" => "link",
		"link" => "billing");
	$user_menu[] = array (
		"text" => "help",
		"type" => "link",
		"link" => "help");
	$mymenu = makeTreeMenu($user_menu,$_REQUEST["addrlink"],"".$_SERVER["PHP_SELF"]."?rub=login","addrlink");
	return $mymenu;
}
	///////////////////////////////
	// The left side menu layout //
	///////////////////////////////
	$menu = draw_left_menu($user_info);
	$leftCont = "<div style=\"white-space: nowrap\" nowrap><b>My mailboxs</b></div>
<center><hr width=\"95%\"></center>
<div align=\"left\" style=\"white-space: nowrap\" nowrap>
$menu<br>
<a href=\"$PHP_SELF?rub=login&sousrub=logout\">Logout</a></div>";
$left = skin("iglobal",$leftCont,"");

	$goodLeft = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td height="1">'.$left.'</td></tr>
<tr><td width=\"100%\">&nbsp;</td></tr>
</table>';

	//////////////////////////////////
	// Create the main page content //
	//////////////////////////////////
	$mainbox_title = "iGlobalWall: user interface";
	if(!isset($_REQUEST["addrlink"]) || $_REQUEST["addrlink"] == ""){
		$main = "<center><h3>Welcome to iGlobalWall anti-spam user
interface:</h3></center>
<center>Please select a menu entry on the left.</center>";
	}else{
		$addr_table = explode('/',$_REQUEST["addrlink"]);
		$first_menu = $addr_table[0];
		$second_menu = $addr_table[1];
		if($first_menu == "my account"){
			$toto = file("rubs/user/your_account.php");
			include("rubs/user/your_account.php");
		}else if($first_menu == "add pop3 account"){
			include("rubs/user/addpop3.php");
		}else if($first_menu == "billing"){
			$main = "<center><h3>Billing:</h3></center>
<center>under constuction !</center>";
		}else if($first_menu == "help"){
			$main = "<center><h3>Help:</h3></center>
<center>under constuction !</center>";
		}else{
			$mainbox_title = "iGlobalWall/$first_menu:";
			if(!isset($second_menu) || $second_menu == ""){
				include("rubs/user/pop_edit.php");
			}else if($second_menu == "senders whitelist"){
				include("rubs/user/sender_whitelist.php");
			}else if($second_menu == "unverified emails"){
				include("rubs/user/unverified_emails.php");
			}else{
				$main = "<center><font color=\"red\">Menu entry code not found: under constuction!</center>";
			}
		}
	}
	//////////////////////////////////
	// Layout main part of the page //
	//////////////////////////////////
	$edito = skin("iglobal",$main,$mainbox_title);

	$main_content = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%"><tr>
	<td width="100% height="1">'.$edito.'</td></tr><tr><td></td></tr></table>';
	$main_content = &$edito;

	//////////////////////////////////
	// Layout left and main content //
	//////////////////////////////////
	if($_REQUEST["hide_left_menu"] != "yes"){
		$content = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td width="1">
'.$goodLeft.'
</td><td valign="top">
'.$main_content.'
</td></tr></table>';
	}else{
		$content = $main_content;
	}
?>