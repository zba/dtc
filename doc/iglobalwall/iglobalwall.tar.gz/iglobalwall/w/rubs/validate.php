<?php

if( !isRandomNum($_REQUEST["randomwallid"]) ){
	die("Incorrect url format!!!");
}

if( $_REQUEST["action"] == "validation_request"){
	if( !isRandomNum($_REQUEST["vefify_text"]) ){
		die("Incorrect number format: did you misstype? Please go back and enter only numbers...");
	}

	$q = "SELECT * FROM validate_url WHERE random_val='".$_REQUEST["randomwallid"]."' AND random_num='".$_REQUEST["vefify_text"]."';";
	$r = mysql_query($q)or die("Cannot query \"$q\" line: ".__LINE__." file:".__FILE__." server said: ".mysql_error());
	$n = mysql_num_rows($r);
	if($n != 1)     die("Cannot found given message randomwallid in database!!!");
	$a = mysql_fetch_array($r);

	$q2 = "SELECT * from mailbox WHERE igw_login='".$a["igw_login"]."' AND pop3_email='".$a["mailbox"]."'";
	$r2 = mysql_query($q2)or die("Cannot query \"$q2\" line: ".__LINE__." file:".__FILE__." server said: ".mysql_error());
	$n2 = mysql_num_rows($r2);
	if($n2 != 1)     die("Cannot found given mailbox in database!!!");
	$a2 = mysql_fetch_array($r2);

	if($a2["autoadd"] != "yes"){
		mail ( $a["igw_login"]."@iglobalwall.com","[iGlobalWall] New user request to be in whitelist",
"Hello ! ".$a["frombox"]." wants to write to you. Please login to iglobalwall and check your
incoming message at http://www.iglobalwall.com.","From: iglobalwalldaemon@iglobalwall.com\r\n" .
     "Reply-To: iglobalwalldaemon@iglobalwall.com\r\n" .
     "X-Mailer: PHP/" . phpversion());

		$q = "UPDATE validate_url SET requested='yes' WHERE random_val='".$_REQUEST["randomwallid"]."';";
		$r = mysql_query($q)or die("Cannot query \"$q\" line: ".__LINE__." file: ".__FILE__." server said: ".mysql_error());

		$main = '<center><h3>Write email confirmation!</h3></center>
<center>You have succesfully sent a request to <b>'.$a["mailbox"].'</b>.<br>
He or she will recieve the message as soon as it accepts your request.
</center>';
	}else{
		messageToWhitelist($_REQUEST["randomwallid"]);
	}
}else{
	$q = "SELECT * FROM validate_url WHERE random_val='".$_REQUEST["randomwallid"]."';";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__."in file ".__FILE__.", mysql said: ".mysql_error());
	$n = mysql_num_rows($r);
	if($n != 1)     die("Cannot found given message randomwallid in database!!!");
	$a = mysql_fetch_array($r);

	$main = '<center><h3>Write email verification!</h3></center>
<center>

<form action="'.$_SERVER["PHP_SELF"].'">
<input type="hidden" name="rub" value="validate">
<input type="hidden" name="action" value="validation_request">
<input type="hidden" name="randomwallid" value="'.$_REQUEST["randomwallid"].'">
Please <b>enter the number</b> you see so we can verify you are a real human.<br>
A request will be sent to <b>'.$a["mailbox"].'</b> so he adds you in his list
of trusted emails.<br><br>
<img src="random_img.php?randomwallid='.$_REQUEST["randomwallid"].'"><br><br>
<input type="text" name="vefify_text" value="">
<input type="submit" value="Ok">
</center>
';
}

$content = skin("iglobal",$main,"Validation");;
?>