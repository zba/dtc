<?php


$leftCont = "<div style=\"white-space: nowrap\" nowrap><b>iGlobalWall news</b></div>
<center><hr width=\"95%\">
<img src=\"gfx/images/rack.jpg\">
<hr width=\"95%\"></center>
<div align=\"left\">Find out how iGlobalWall works.</div>
<div align=\"right\"><a href=\"$PHP_SELF?rub=findout\"><img src=\"gfx/images/arrow.gif\" border=\"0\"></a></div>";
$left = skin("iglobal",$leftCont,"");

$goodLeft = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td height="1">'.$left.'</td></tr>
<tr><td width=\"100%\">&nbsp;</td></tr>
</table>';


$login_txt = "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\" height=\"100%\"><tr>
<form action=\"$PHP_SELF\"><input type=\"hidden\" name=\"rub\" value=\"login\">
<input type=\"hidden\" name=\"action\" value=\"login\">
<td><input type=\"text\" name=\"igw_login\" value=\"\"></td>
</tr><tr>
<td><input type=\"password\" name=\"igw_pass\" value=\"\"></td>
</tr><tr>
<td width=\"100%\"><input type=\"checkbox\" name=\"igw_remember\" value=\"\">&nbsp;<input
border=\"0\" type=\"image\" src=\"gfx/skin/login/sign_in.gif\"></td>
</tr></table>
";
$loginform = skin("login",$login_txt,"");

$main_edito_text = $txt_edito[$lang]."<br><center><h3>iGlobalWall: The
ultimate anti-spam service.</h3>Stop Unsolicited Emails forever!</center><br><br>
<BLOCKQUOTE>
<center>
<br>
	<form action=\"$PHP_SELF\"><input type=\"hidden\" name=\"rub\" value=\"login\">
<input type=\"hidden\" name=\"action\" value=\"login\">
		<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"1\" height=\"1\">
			<tr>
				<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Login:</td>
				<td><input type=\"text\" name=\"igw_login\" value=\"\"></td>
			</tr><tr>
				<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Pass:</td>
				<td><input type=\"password\" name=\"igw_pass\" value=\"\"></td>
			</tr><tr>
				<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Remember me:</td>
				<td><input type=\"checkbox\" name=\"igw_remember\" value=\"\"></td>
			</tr><tr>
				<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>&nbsp;</td>
				<td><input type=\"submit\" value=\"Ok\"></td>
			</tr>
		</table>
	</form><br>
	<a href=\"$PHP_SELF?rub=register\">Register</a> - <a href=\"#\">Lost Password</a><br><br>
<div align=\"right\"><i>iGlobalNetworks and GPLHost</i></div><br><br>
</center>
</BLOCKQUOTE>
";

$main_edito_text = $txt_edito[$lang]."<br><center><h3>iGlobalWall: The
ultimate anti-spam service.</h3>Stop Unsolicited Emails forever!</center><br><br>
<center>$loginform<br>
	<a href=\"$PHP_SELF?rub=register\">Register</a> - <a href=\"#\">Lost Password</a><br><br>
</center><div align=\"right\"><i>iGlobalNetworks and GPLHost</i></div>
";
$edito = skin("iglobal","$main_edito_text","Welcom to iGLobalWall");

$dtc_home_text = "
<div align=\"justify\">how does it work ?</div>
";
$dtc_home_txt_img = '<table cellspacing="8" cellpadding="0" border="0" width="100%" height="100%">
<tr>
	<td width="1" height="100%"><a href="'.$PHP_SELF.'?">IMAGE</a></td>
	<td width="8">&nbsp;</td>
	<td width="100%">'.$dtc_home_text.'</td>
</tr></table>';
$dtcSkined = skin("iglobal",$dtc_home_txt_img,"How does it works");

$techno = "Our servers are powered by Debian woody (stable), using
the following sofware:<br><br>
<b>Web:</b> apache 1.3 with mod_log_sql, mod_ssl and mod_php4<br>
<b>FTP:</b> ProFTPd with mysql backend<br>
<b>Email:</b> Qmail MTA server with SSLWraper for secure SMTP and POP3, and the IMP webmail<br>
<b>Admin Panel:</b> Domain Technologie Control<br>
";
$technoSkined = skin("iglobal",$techno,"Technologies|debian.gif");

$backSplit = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td height="100%" width="50%">'.$dtcSkined.'</td>
<td width="50%">'.$technoSkined.'</td>
</tr></table>';

$main_content = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr>
	<td width="100% height="1">'.$edito.'</td>
</tr><tr>
	<td width="100%">'.$backSplit.'</td>
</tr><tr>
	<td></td>
</tr>
</table>';

// Layout left and main content
$content = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td width="1">'.$goodLeft.'</td><td valign="top">'.$main_content.'</td></tr>
</table>';

?>
