<?php


$boxs = &$user_info["table_mailbox"];
$nbr_boxs = sizeof($boxs);

for($i=0;$i<$nbr_boxs;$i++){
	$email = &$boxs[$i]["pop3_email"];
	if($i != 0)	$txt2 .= " - ";
	$txt2 .= '<a href="'.$_SERVER["PHP_SELF"].'?rub=login&addrlink='.$_REQUEST["addrlink"].'&action=remove_mailbox&email='.$email.'">'.$email.'</a>';
}

$q = "SELECT * from $table_validate_url WHERE igw_login='".$user_info["igw_login"]."' AND requested='yes' LIMIT 20;";
$r = mysql_query($q)or die("Cannot execute query: \"$q\" line:".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
$n = mysql_num_rows($r);
$number_of_pending = $n;

$bgtag1 = ' bgcolor="#74748A"';
$bgtag2 = ' bgcolor="#A4A4BA"';

$txt .= "<table border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
<tr><td$bgtag1>ID</td><td$bgtag1>Date</td><td$bgtag1>From</td><td$bgtag1>To</td><td$bgtag1>Subject</td><td$bgtag1>Action</td></tr>";
$start_url = $_SERVER["PHP_SELF"].'?rub=login';
for($i=0;$i<$n;$i++){
	if($i % 2){
		$tag = $bgtag1." style=\"white-space:nowrap\" nowrap";
	}else{
		$tag = $bgtag2." style=\"white-space:nowrap\" nowrap";
	}
	$a = mysql_fetch_array($r);
	$line = $i + 1;
	$txt .= "<tr>";
	$txt .= "<td$tag>". $line ."</td>";
	$txt .= "<td$tag>".$a['date']."</td>";
	$txt .= "<td$tag>"."<a href=\"$start_url&addrlink=".$a["mailbox"]."/unverified emails"."&msgid=".$a["random_val"]."&action=viewmsg\">".$a['frombox']."</a></td>";
	$txt .= "<td$tag>"."<a href=\"$start_url&addrlink=".$a["mailbox"]."/unverified emails"."&msgid=".$a["random_val"]."&action=viewmsg\">".$a['mailbox']."</a></td>";
	if(strlen($a['subject']) > $MAX_SUBJECT_SMALL){
		$txt .= "<td$tag style=\"white-space: nowrap\" nowrap>".substr($a['subject'],0,$MAX_SUBJECT_SMALL-3)."...</td>";
	}else
		$txt .= "<td$tag style=\"white-space: nowrap\" nowrap>".$a['subject']."</td>";
	$txt .= "<td$tag>"."<a href=\"$start_url&addrlink=".$_REQUEST['addrlink']."&msgid=".$a["random_val"]."&action=msg2whitelist\">Whitelist</a>".
" -  <a href=\"$start_url&addrlink=".$_REQUEST['addrlink']."&msgid=".$a["random_val"]."&action=deletefromsql&offset=$offs\">Delete</a>".
"</td>";
	$txt .= "</tr>";
}
$txt .= "</table>";

if($number_of_pending > 0){
	$pendings = "The following request are pending: $txt<br><br>";
}else{
	$pendings = "You curently have no whitelist request pending.<br><br>";
}

$main = "<center><h3>Your account:</h3>
$pendings
Remove an email from iglobalwall checking:<br>
$txt2</center>";

?>