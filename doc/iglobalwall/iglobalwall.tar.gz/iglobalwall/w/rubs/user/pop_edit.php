<?php

$nbrbox = sizeof($user_info["table_mailbox"]);

for($i=0;$i<$nbrbox;$i++){
	if($user_info["table_mailbox"][$i]["pop3_email"] == $first_menu){
		$boxnum = $i;
	}
}

if($user_info["table_mailbox"][$boxnum]["checkit"] == "yes"){
	$check = " checked";
}else{
	$check = "";
}

if($user_info["table_mailbox"][$boxnum]["autoadd"] == "yes"){
	$check_auto = " checked";
}else{
	$check_auto = "";
}

// echo $user_info["table_mailbox"][$boxnum]["autodel"];
switch($user_info["table_mailbox"][$boxnum]["autodel"]){
case 0:
	$check0 = " selected ";
	break;
case 1:
	$check1 = " selected ";
	break;
case 2:
	$check2 = " selected ";
	break;
case 3:
	$check3 = " selected ";
	break;
default:
case 7:
	$check7 = " selected ";
	break;
case 14:
	$check14 = " selected ";
	break;
case 21:
	$check21 = " selected ";
	break;
case 28:
	$check28 = " selected ";
	break;
}

if($user_info["table_mailbox"][$boxnum]["bounce_msg"] == NULL ||
$user_info["table_mailbox"][$boxnum]["bounce_msg"] == "NULL"){
	$bnc_txt = "";
}else{
	$bnc_txt = $user_info["table_mailbox"][$boxnum]["bounce_msg"];
}

$main = '<center><h3>'.$first_menu.': Configuration</h3></center>
<center>

<form action="'.$_SERVER["PHP_SELF"].'">
<input type="hidden" name="rub" value="login">
<input type="hidden" name="action" value="edit_pop3">
<input type="hidden" name="addrlink" value="'.$_REQUEST["addrlink"].'">
<input type="hidden" name="igw_email" value="'.$_REQUEST["addrlink"].'">

<table cellspacing="0" cellpadding="4" border="0" width="1" height="1">
<tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your email address:</td>
	<td><b>'.$user_info["table_mailbox"][$boxnum]["pop3_email"].'</b></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your Mail/pop3 server addresse:</td>
	<td><input type="text" name="igw_pop3_srv" value="'.$user_info["table_mailbox"][$boxnum]["pop3_server"].'"></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your pop3 login name:</td>
	<td><input type="text" name="igw_pop3_username" value="'.$user_info["table_mailbox"][$boxnum]["pop3_login"].'"></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your pop3 password (leave blank to keep):</td>
	<td><input type="password" name="igw_pop3_pass" value=""></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Delete all unverified emails:</td>
	<td><select name="autodel">
<option value="0" '.$check0.' >never</option>
<option value="1" '.$check1.' >after 1 day</option>
<option value="2" '.$check2.' >after 2 days</option>
<option value="3" '.$check3.' >after 3 days</option>
<option value="7" '.$check7.' >after 1 week</option>
<option value="14" '.$check14.' >after 2 weeks</option>
<option value="21" '.$check21.' >after 3 weeks</option>
</select></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Check and retrive mail from this mailbox each 5 minutes:</td>
	<td><input type="checkbox" name="checkit" value="yes"'.$check.'></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Automaticaly add to whitelist confirmed users:</td>
	<td><input type="checkbox" name="autoadd" value="yes"'.$check_auto.'></td>
</tr><tr>
	<td colspan="2"><b><u>Bounce message:</u></b><br>Enter here the message to bounce when someone not in
your whitelist wants to write to you. The word <b>!!!URL!!!</b> will be
replaced by the address that user will have to click to enter your
whitelist (you can put it more than one time in the text). If you leave
it blank (eg less than 5 chars), then the default bounce text will be used.<br><textarea rows="7" cols="55" name="custom_bounce">'.$bnc_txt.'</textarea></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap></td>
	<td><input type="submit" value="Ok"></td>
</tr></table>
</form>

</center>';

?>