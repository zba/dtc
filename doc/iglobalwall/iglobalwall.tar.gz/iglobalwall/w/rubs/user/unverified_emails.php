<?php

$MAX_FROM_SMALL = 30;
$bgtag1 = ' bgcolor="#74748A" style="white-space:nowrap" nowrap';
$bgtag2 = ' bgcolor="#A4A4BA" style="white-space:nowrap" nowrap';

switch($_REQUEST["action"]){
case "view_header":
	if(!isRandomNum($_REQUEST["msgid"])){
		die("This is not a msg id!!!");
	}
	$q = "SELECT * from $table_validate_url WHERE igw_login='".$user_info["igw_login"]."' AND mailbox='$first_menu' AND random_val='".$_REQUEST["msgid"]."' LIMIT 20;";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$n = mysql_num_rows($r);
	if($n != 1)die("message not found!");
	$a = mysql_fetch_array($r);
	$msg_core = strstr($a['message'],"\r\n\r\n");
// 	echo ($next);// = strtok(NULL,"\n\n");

	$txt .= "<table border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
<tr><td$bgtag2>Header:<pre><font size=\"-2\" color=\"black\">".htmlspecialchars(substr($a['message'],0,strlen($a['message'])-strlen($msg_core)))."</font></pre></td></tr>
";
	break;
case "viewmsg":
	if(!isRandomNum($_REQUEST["msgid"])){
		die("This is not a msg id!!!");
	}
	$q = "SELECT * from $table_validate_url WHERE igw_login='".$user_info["igw_login"]."' AND mailbox='$first_menu' AND random_val='".$_REQUEST["msgid"]."' LIMIT 20;";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$n = mysql_num_rows($r);
	if($n != 1)die("message not found!");
	$a = mysql_fetch_array($r);
	$msg_core = strstr($a['message'],"\r\n\r\n");
// 	echo ($next);// = strtok(NULL,"\n\n");
	$whitelist_link = "<a href=\"".$_SERVER["PHP_SELF"].'?rub=login&addrlink='.$_REQUEST['addrlink']."&msgid=".$a["random_val"]."&action=msg2whitelist\">Whitelist</a>";
	$viewhead_link = "<a target=\"_blank\" href=\"".$_SERVER["PHP_SELF"].'?rub=login&addrlink='.$_REQUEST['addrlink']."&msgid=".$a["random_val"]."&action=view_header&hide_left_menu=yes\">View header</a>";

	$txt .= "<table border=\"1\" cellspacing=\"0\" cellpadding=\"4\">
<tr><td$bgtag2>Action: $whitelist_link - $viewhead_link</td></tr>
<tr><td$bgtag1>From: ".$a['frombox']."</td></tr>
<tr><td$bgtag2>Date: ".$a['date']." | ".$a['time']."</td></tr>
<tr><td$bgtag1>Subject: ".$a['subject']."</td></tr>
<tr><td$bgtag2><pre><font size=\"-1\" color=\"black\">".htmlspecialchars($msg_core)."</font></pre></td></tr>
";
	break;
default:
	$q = "SELECT * from $table_validate_url WHERE igw_login='".$user_info["igw_login"]."' AND mailbox='$first_menu';";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$max = mysql_num_rows($r);

	$start_url = $_SERVER["PHP_SELF"].'?rub=login&addrlink='.$_REQUEST['addrlink'];
	if(isRandomNum($_REQUEST["offset"])){
		$offs = $_REQUEST["offset"];
	}else{
		$offs = 0;
	}

	if($offs >= $max)	$offs = $max - 20;
	if($offs < 0)	$offs = 0;

	$limitparm = $offs.",20";
	$q = "SELECT * from $table_validate_url WHERE igw_login='".$user_info["igw_login"]."' AND mailbox='$first_menu' ORDER BY date DESC,time DESC LIMIT $limitparm;";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$n = mysql_num_rows($r);

	$txt .= "<a href=\"$start_url&action=deleteall_unverified\">Delete all unverified messages</a>
<table border=\"1\" cellspacing=\"0\" cellpadding=\"4\"
width=\"100%\">
<tr><td colspan=\"7\" bgcolor=\"#A4A4BA\">

<table border=\"0\" cellspacing=\"0\" cellpadding=\"4\">
<tr><td style=\"white-space:nowrap\" nowrap>";

	if($offs != 0){
		$txt .= "<a href=\"$start_url&offset=0\">&lt;&lt;first</a> - ";
		$bla = $offs - 20;
		if($bla < 0)
			$bla = 0;
		$txt .= "<a href=\"$start_url&offset=". $bla ."\">&lt;prev</a>";
	}else{
		$txt .= "<b>&lt;&lt;first</b> - ";
		$bla = $offs - 20;
		if($bla < 0)
			$bla = 0;
		$txt .= "<b>&lt;prev</b>";
	}

	$txt .= "</td><td width=\"100%\"><center>";

	if($max > 20){
		for($i=0;$i<$max-1;$i += 20){
			$start = $i + 1;
			$end = $i + 20;
			if($end > $max)	$end = $max;
			if($i == $offs){
				$txt .= $start."-".$end." ";
			}else{
				$txt .= "<a href=\"$start_url&offset=$i\">".$start."-".$end."</a> ";
			}
		}
	}

	$txt .= "</center></td><td style=\"white-space:nowrap\" nowrap>";


	if($max > 20 && $offs < $max - 20){
		$bla = $offs + 20;
		if($bla > $max - 20)
			$bla = $max - 20;
		$txt .= "<a href=\"$start_url&offset=". $bla ."\">next&gt;</a> - ";
		$bli = $max - 20;
		$txt .= "<a href=\"$start_url&offset=". $bli ."\">last&gt;&gt;</a>";
	}else{
		$bla = $offs + 20;
		if($bla > $max - 20)
			$bla = $max - 20;
		$txt .= "<b>next&gt;</b> - ";
		$bli = $max - 20;
		$txt .= "<b>last&gt;&gt;</b>";
	}
	$txt .= "</td></tr></table></td></tr>
<tr><td$bgtag1>ID</td><td$bgtag1>Request</td><td$bgtag1>Date</td><td$bgtag1>From</td><td$bgtag1>Subject</td><td$bgtag1>Size</td><td$bgtag1>Action</td></tr>";
	for($i=0;$i<$n;$i++){
		if($i % 2){
			$tag = $bgtag1;
		}else{
			$tag = $bgtag2;
		}
		$a = mysql_fetch_array($r);
		$txt .= "<tr>";
		$line = $i + 1 + $offs;
		$txt .= "<td$tag>".$line."</td>";
		if($a['requested'] == 'yes'){
			$color = '<font color="red">';
			$colo2 = '</font>';
		}else{
			$color = '';
			$colo2 = '';
		}
		$txt .= "<td$tag>$color".$a['requested']."$colo2</td>";
		if($a['date'] == date("Y-m-d"))
			$txt .= "<td$tag>".$a['time']."</td>";
		else
			$txt .= "<td$tag>".$a['date']."</td>";
		if( strlen($a['frombox']) > $MAX_FROM_SMALL ){
			$fromtxt = substr($a['frombox'],0,$MAX_FROM_SMALL-3)."...";
		}else{
			$fromtxt = $a['frombox'];
		}
		$txt .= "<td$tag>"."<a href=\"$start_url"."&msgid=".$a["random_val"]."&action=viewmsg\">".$fromtxt."</a></td>";
		if(strlen($a['subject']) > $MAX_SUBJECT_SMALL){
			$txt .= "<td$tag style=\"white-space: nowrap\" nowrap>".substr($a['subject'],0,$MAX_SUBJECT_SMALL-3)."...</td>";
		}else
			$txt .= "<td$tag style=\"white-space: nowrap\" nowrap>".$a['subject']."</td>";
		$txt .= "<td$tag>".smartByte(strlen($a["message"]))."</td>";
		$txt .= "<td$tag>".
"<a href=\"$start_url&msgid=".$a["random_val"]."&action=msg2whitelist&offset=$offs\">Whitelist</a> ".
"<a href=\"$start_url&msgid=".$a["random_val"]."&action=deletefromsql&offset=$offs\">Delete</a>".
"</td>";
		$txt .= "</tr>";
	}
	break;
}
$txt .= '</table>';

$main = '<center><h3>'.$first_menu.': Unverified emails</h3></center>
<center>'.$txt.'</center>
';

?>
