<?php

include("inc/jupload.php");

$list = $user_info["table_whitelist"];
$sizeList = sizeof($list);

// Select only this email whitelist
$cntdom=0;
$cntmlst=0;
$cntto=0;
for($i=0;$i<$sizeList;$i++){
	if($list[$i]["mailbox"] == $first_menu){
		if($list[$i]["mail_to"] == NULL){
			if($list[$i]["mail_from_user"] == "*"){
				$domlist[] = $list[$i];
				if($cntdom != 0)
					$domlisttxt .= " - ";
				$domlisttxt .= "<a href=\"".$_SERVER["PHP_SELF"]."?rub=login&addrlink=".$_REQUEST["addrlink"]."&action=del_whitelist_domain&domain_addr=".$list[$i]["mail_from_domain"]."\">".$list[$i]["mail_from_domain"]."</a>";
				$cntdom++;
			}else{
				$maillst[] = $list[$i];
				if($cntmlst != 0)
					$maillisttxt .= " - ";
				$maillisttxt .= "<a href=\"".$_SERVER["PHP_SELF"]."?rub=login&addrlink=".$_REQUEST["addrlink"]."&action=del_whitelist_email&domain_addr=".$list[$i]["mail_from_domain"]."&mail_from_user=".$list[$i]["mail_from_user"]."\">".$list[$i]["mail_from_user"]."@".$list[$i]["mail_from_domain"]."</a>";
				$cntmlst++;
			}
		}else{
			if($cntmlst != 0)
				$tolisttxt .= " - ";
			$tolisttxt .= "<a href=\"".$_SERVER["PHP_SELF"]."?rub=login&addrlink=".$_REQUEST["addrlink"]."&action=del_whitelist_to&mail_to=".$list[$i]["mail_to"]."\">".$list[$i]["mail_to"]."</a>";
			$cntto++;
		}
	}
}

$zemail = str_replace("@","#",$first_menu);
$java_cvs_upload = uploadObject("Upload CSV","filename_value","http://www.iglobalwall.com/jupload/getupload.php?igw_login=".$user_info["igw_login"].'&igw_pass='.$user_info["igw_pass"]."&mailbox=$zemail");

$main = '<center><h3>'.$first_menu.': Sender whitelist</h3></center>
<center>
Single address whitelist:
'.$maillisttxt.'
<form action="'.$_SERVER["PHP_SELF"].'">
<input type="hidden" name="rub" value="login">
<input type="hidden" name="action" value="whitelist_add_email">
<input type="hidden" name="addrlink" value="'.$_REQUEST["addrlink"].'">

<table cellspacing="0" cellpadding="4" border="0" width="1" height="1">
<tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Email address to add:</td>
	<td style="white-space:nowrap;text-align:right" nowrap><input type="text" name="email" value=""> <input type="submit" value="Ok"></td>
</tr></table></form>
Domain whitelist:
'.$domlisttxt.'
<form action="'.$_SERVER["PHP_SELF"].'">
<input type="hidden" name="rub" value="login">
<input type="hidden" name="action" value="whitelist_add_domain">
<input type="hidden" name="addrlink" value="'.$_REQUEST["addrlink"].'">
<table cellspacing="0" cellpadding="4" border="0" width="1" height="1">
<tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Domain address to add:</td>
	<td style="white-space:nowrap;text-align:right" nowrap><input type="text" name="domain" value=""> <input type="submit" value="Ok"></td>
</tr></table></form>
To, Cc and Bcc whitelist (usefull for mailing lists):
'.$tolisttxt.'
<form action="'.$_SERVER["PHP_SELF"].'">
<input type="hidden" name="rub" value="login">
<input type="hidden" name="action" value="whitelist_add_to">
<input type="hidden" name="addrlink" value="'.$_REQUEST["addrlink"].'">
<table cellspacing="0" cellpadding="4" border="0" width="1" height="1">
<tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Address to add:</td>
	<td style="white-space:nowrap;text-align:right" nowrap><input type="text" name="address" value=""> <input type="submit" value="Ok"></td>
</tr></table></form><br><br>
</center><b>CSV import from address-book:</b><br>
If your email client is capable of exporting CSV address-book file (under
Outook Express, it\'s in menu File -&gt; Export -&gt; Address-book), then you
can upload it. The script will look for a field named "E-Mail Address". iGlobalWall
will then include all email addresses to the whitelist.<br>
<center><br>
'.$java_cvs_upload.'<br><br>
<form action="'.$_SERVER["PHP_SELF"].'">
<input type="hidden" name="rub" value="login">
<input type="hidden" name="addrlink" value="'.$_REQUEST["addrlink"].'">
When upload is done, please click the refresh button bellow:<br>
<input type="submit" value="Refresh">
</form>
</center>
';

?>