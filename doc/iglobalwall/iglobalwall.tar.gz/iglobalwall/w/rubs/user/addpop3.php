<?php

$main = '<center><h3>Add a pop3 account:</h3></center>
<center>

<form action="'.$_SERVER["PHP_SELF"].'">
<input type="hidden" name="rub" value="login">
<input type="hidden" name="action" value="add_pop3_account">
<input type="hidden" name="addrlink" value="'.$_REQUEST["addrlink"].'">

<table cellspacing="0" cellpadding="4" border="0" width="1" height="1">
<tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your email address:</td>
	<td><input type="text" name="igw_email" value=""></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your Mail/pop3 server addresse:</td>
	<td><input type="text" name="igw_pop3_srv" value=""></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your pop3 login name:</td>
	<td><input type="text" name="igw_pop3_username" value=""></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap>Your pop3 password:</td>
	<td><input type="text" name="igw_pop3_pass" value=""></td>
</tr><tr>
	<td align="right" style="white-space:nowrap;text-align:right" nowrap></td>
	<td><input type="submit" value="Ok"></td>
</tr></table>
</form>

</center>';

?>