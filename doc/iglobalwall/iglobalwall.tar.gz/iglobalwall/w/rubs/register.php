<?php

$mailbox_user_path="/var/www/sites/zigo/iglobalwall.com/Mailboxs";

$leftCont2 = "<div style=\"white-space: nowrap\" nowrap><b>Your IP and SSL</b></div>
<center><hr width=\"95%\"></center>
<div align=\"left\">Find out how and why you shoult take
a dedicated IP, certified bandwidth and SSL on a shared server</div>
<div align=\"right\"><a href=\"$PHP_SELF?rub=services&sousrub=sharedssl\"><img src=\"gfx/images/arrow.gif\" border=\"0\"></a></div>";
$left2 = skin("iglobal",$leftCont2,"");

$goodLeft = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td height="1">'.$left.'</td></tr>
<tr><td width=\"100%\">&nbsp;</td></tr>
</table>';

$step1_form_txt = "<b><img src=\"step1.png\">STEP 1</b> - <img src=\"mailboxs.png\">STEP 2 - <img src=\"save.png\">STEP 3
<form action=\"$PHP_SELF\"><input type=\"hidden\" name=\"rub\" value=\"$rub\">
	<input type=\"hidden\" name=\"step\" value=\"1\">
	<table cellspacing=\"0\" cellpadding=\"4\" border=\"0\" width=\"1\" height=\"1\">
		<tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Full name(64chars max):</td>
			<td><input type=\"text\" name=\"igw_fullname\" value=\"".$_REQUEST["igw_fullname"]."\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Choose a iGlobalWall username (4 to 16 chars):</td>
			<td><input type=\"text\" name=\"igw_login\" value=\"".$_REQUEST["igw_login"]."\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Choose a iGlobalWall password (4 to 16 chars):</td>
			<td><input type=\"password\" name=\"igw_pass\" value=\"\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Verify password:</td>
			<td><input type=\"password\" name=\"igw_pass2\" value=\"\"></td>
		</tr><tr>
			<td align=\"right\"style=\"white-space:nowrap;text-align:right\" nowrap>Remember me:</td>
			<td><input type=\"checkbox\" name=\"igw_remember\" value=\"yes\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>&nbsp;</td>
			<td><input type=\"submit\" value=\"Next\"></td>
		</tr>
	</table>
";

function test_step1(){
	global $igw_fullname;
	global $igw_login;
	global $igw_pass;

	global $error;
	global $hiddens_parms;

	global $table_users;

	$igw_fullname = mysql_escape_string($_REQUEST["igw_fullname"]);
	if($igw_fullname == ""){
		$error = "<font color=\"red\">Field fullname is umpty!</font><br>";
		return false;
	}

	$igw_login = $_REQUEST["igw_login"];
	if(!isDTCPassword($igw_login)){
		$error = "<font color=\"red\">Wrong format for login or field umpty!</font><br>";
		return false;
	}
	$q = "SELECT * FROM $table_users WHERE igw_login='$igw_login';";
	$r = mysql_query($q)or die("Could not execute $q in file: ".__FILE__." line: ".__LINE__.": ".mysql_error());
	$n = mysql_num_rows($r);
	if($n >= 1){
		$error = "<font color=\"red\">User already taken!</font><br>";
		return false;
	}

	$igw_pass = $_REQUEST["igw_pass"];
	$igw_pass2 = $_REQUEST["igw_pass2"];
	if(!isDTCPassword($igw_pass)){
		$error = "<font color=\"red\">Wrong format for password or field umpty!</font><br>";
		return false;
	}
	if($igw_pass2 != $igw_pass){
		$error = "<font color=\"red\">Password does not match!</font><br>";
		return false;
	}
	if($_REQUEST["igw_remember"] == "yes"){
		$hiddens_parms .= "<input type=\"hidden\" name=\"igw_remember\" value=\"yes\">";
	}
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_fullname\" value=\"$igw_fullname\">";
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_login\" value=\"$igw_login\">";
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_pass\" value=\"$igw_pass\">";
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_pass2\" value=\"$igw_pass\">";
	return true;
}

$step2_form_txt = "<img src=\"step1.png\">STEP 1 - <b><img src=\"mailboxs.png\">STEP 2</b> - <img src=\"save.png\">STEP 3
<form action=\"$PHP_SELF\"><input type=\"hidden\" name=\"rub\" value=\"$rub\">
	<input type=\"hidden\" name=\"step\" value=\"2\">
	<table cellspacing=\"0\" cellpadding=\"4\" border=\"0\" width=\"1\" height=\"1\">
		<tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Your email addresse:</td>
			<td><input type=\"text\" name=\"igw_pop_email\" value=\"".$_REQUEST["igw_pop_email"]."\"></td>
		</tr><tr>
			<td width=\"50%\" align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Your Mailbox/Pop mail server:</td>
			<td width=\"50%\"><input type=\"text\" name=\"igw_pop_srv\" value=\"".$_REQUEST["igw_pop_srv"]."\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>You Mailbox user name:</td>
			<td><input type=\"text\" name=\"igw_pop_username\" value=\"".$_REQUEST["igw_pop_username"]."\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Your Mailbox password:</td>
			<td><input type=\"password\" name=\"igw_pop_pass\" value=\"\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Verify password:</td>
			<td><input type=\"password\" name=\"igw_pop_pass2\" value=\"\"></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>&nbsp;</td>
			<td><input type=\"submit\" value=\"Next\"></td>
		</tr>
	</table>
";

function test_step2(){
	global $igw_pop_srv;
	global $igw_pop_email;
	global $igw_pop_username;
	global $igw_pop_pass;
	global $igw_pop_pass2;

	global $hiddens_parms;
	global $error;

//	if(!isHostnameOrIP($_REQUEST["igw_pop_srv"])){
//		$error = "<font color=\"red\">Given address does not look like a pop3 server!</font><br>";
//		return false;
//	}

	$igw_pop_email = $_REQUEST["igw_pop_email"];
	if(!isValidEmail($igw_pop_email)){
		$error = "<font color=\"red\">Email address does not look like an email address: it should be user@domain.com!</font><br>";
		return false;
	}

	if($_REQUEST["igw_pop_pass"] != $_REQUEST["igw_pop_pass2"]){
		$error = "<font color=\"red\">Pop3 server does not match!</font><br>";
		return false;
	}

	$igw_pop_srv = $_REQUEST["igw_pop_srv"];
	$igw_pop_ip = gethostbyname($igw_pop_srv);
	if($igw_pop_srv == $igw_pop_ip){
		$error = "<font color=\"red\">Could not resolv pop3 server!</font><br>";
		return false;
	}
	//$soc = socket_create(AF_INET,$SOCK_STREAM, SOL_TCP);
	$soc = fsockopen($igw_pop_srv,110);
	if($soc == false){
		$error = "<font color=\"red\">Could not connect to pop3 server!</font><br>";
		return false;
	}

	$popline = fgets($soc,1024);
	if(!strstr($popline,"+OK")){
		$error = "<font color=\"red\">Server did not send OK after connect!</font>: $popline<br>";
		return false;
	}

	if(!fwrite($soc,"USER ".$_REQUEST["igw_pop_username"]."\n")){
		$error = "<font color=\"red\">Could not write to pop3 server!</font><br>";
		return false;
	}
	$igw_pop_username = $_REQUEST["igw_pop_username"];

	$popline = fgets($soc,1024);
	if(!strstr($popline,"+OK")){
		$error = "<font color=\"red\">Server did not send OK after USER!</font>$popline<br>";
		return false;
	}

	if(!fwrite($soc,"PASS ".$_REQUEST["igw_pop_pass"]."\n")){
		$error = "<font color=\"red\">Could not write to pop3 server for password!</font><br>";
		return false;
	}

	$popline = fgets($soc,1024);
	if(!strstr($popline,"+OK")){
		$error = "<font color=\"red\">Server did not send OK after PASS!</font>$popline<br>";
		return false;
	}
	$igw_pop_username = $_REQUEST["igw_pop_username"];
	$igw_pop_pass = $_REQUEST["igw_pop_pass"];
	$igw_pop_srv = $_REQUEST["igw_pop_srv"];
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_pop_email\" value=\"$igw_pop_email\">";
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_pop_pass\" value=\"$igw_pop_pass\">";
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_pop_pass2\" value=\"$igw_pop_pass\">";
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_pop_username\" value=\"$igw_pop_username\">";
	$hiddens_parms .= "<input type=\"hidden\" name=\"igw_pop_srv\" value=\"$igw_pop_srv\">";
	return true;
}

$step3_form_txt = "<img src=\"step1.png\">STEP 1 - <img src=\"mailboxs.png\">STEP 2 - <b><img src=\"save.png\">STEP 3</b><br><br>
Your pop3 account has been verified.
<form action=\"$PHP_SELF\"><input type=\"hidden\" name=\"rub\" value=\"$rub\">
	<input type=\"hidden\" name=\"step\" value=\"3\">
	<table cellspacing=\"0\" cellpadding=\"4\" border=\"0\" width=\"1\" height=\"1\">
		<tr>
			<td width=\"50%\" align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Full Name:</td>
			<td width=\"50%\"><b>$igw_fullname</b></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Email address:</td>
			<td><b>$igw_pop_email</b></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>iGlobalWall username:</td>
			<td><b>$igw_login</b></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Mailbox/POP3 Mail Server:</td>
			<td><b>$igw_pop_srv</b></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap>Your Mailbox Login:</td>
			<td><b>$igw_pop_username</b></td>
		</tr><tr>
			<td align=\"right\" style=\"white-space:nowrap;text-align:right\" nowrap><input type=\"submit\" name=\"correct\" value=\"Correct\"></td>
			<td><input type=\"submit\" name=\"confirm\" value=\"Confirm\"></td>
		</tr>
	</table>
";

function test_step3(){
	return true;
}

$step4_form_txt = "<br><br><b>Your account has been recorded!</b><br>
<a href=\"$PHP_SELF?rub=login&action=login&igw_login=$igw_login&igw_pass=$igw_pass\">Go and login to this account</a>";

$step = $_REQUEST["step"];
if(!isset($step) || $step == ""){
	$steps = $step1_form_txt;
}else if($step == 1){
	if(!test_step1()){
		$steps = $step1_form_txt;
	}else{
		$steps = $step2_form_txt;
	}
}else if($step == 2){
	if(!test_step1()){
		$steps = $step1_form_txt;
	}else if(!test_step2()){
		$steps = $step2_form_txt;
	}else{
		$steps = $step3_form_txt;
	}
}else if($step == 3){
	if(!test_step1()){
		$steps = $step1_form_txt;
	}else if(!test_step2()){
		$steps = $step2_form_txt;
	}else if(!test_step3()){
		$steps = $step3_form_txt;
	}
	if($_REQUEST["confirm"] == "" || !isset($_REQUEST["confirm"])){
		$steps = $step1_form_txt;
	}else{
		if($igw_remember == 'yes')
			$igw_remember_me = 'yes';
		else
			$igw_remember_me = 'no';

		// Create spamsnag user
		$q = "INSERT INTO $table_users (igw_login,igw_pass,full_name,remember_me) VALUES ('$igw_login','$igw_pass','$igw_fullname','$igw_remember_me');";
		$r = mysql_query($q)or die("Could not execute $q in file: ".__FILE__." line: ".__LINE__.": ".mysql_error());
		$q = "INSERT INTO $table_mailbox (igw_login,pop3_email,pop3_server,pop3_login,pop3_pass,checkit) VALUES ('$igw_login','$igw_pop_email','$igw_pop_srv','$igw_pop_username','$igw_pop_pass','yes');";
		$r = mysql_query($q)or die("Could not execute $q in file: ".__FILE__." line: ".__LINE__.": ".mysql_error());

		// Create mailbox directory
		$mailbox_path = $mailbox_user_path."/$igw_login";

		if(!file_exists("$mailbox_path"))
			mkdir("$mailbox_path", 0755);
		if(!file_exists("$mailbox_path/Maildir"))
			mkdir("$mailbox_path/Maildir", 0755);
		if(!file_exists("$mailbox_path/Maildir/cur"))
			mkdir("$mailbox_path/Maildir/cur", 0755);
		if(!file_exists("$mailbox_path/Maildir/new"))
			mkdir("$mailbox_path/Maildir/new", 0755);
		if(!file_exists("$mailbox_path/Maildir/tmp"))
			mkdir("$mailbox_path/Maildir/tmp", 0755);

		// Create .qmail file
		$dot_qmail  = "|/usr/sbin/iglobalwall_spam_chk\n";
		$dot_qmail .= "./Maildir/\n";
		$fp = fopen("$mailbox_path/.qmail","w");
		fwrite($fp,$dot_qmail);
		fclose($fp);

		// Insert mailbox into DTC database
		mysql_select_db($mysql_dtc_db)or die('Cannot select db "dtc" !');
		$crypted_pass = crypt($igw_pass);
		$q = "INSERT INTO pop_access (id,home,mbox_host,crypt,passwd,localdeliver) VALUES ('$igw_login','$mailbox_path','$mysql_dtc_domain','$crypted_pass','$igw_pass','yes');";
		$r = mysql_query($q)or die("Could not execute $q in file: ".__FILE__." line: ".__LINE__.": ".mysql_error());

		$q = "UPDATE cron_job SET qmail_newu='yes',gen_qmail='yes',restart_qmail='yes' WHERE 1;";
		$r = mysql_query($q)or die("Could not execute $q in file: ".__FILE__." line: ".__LINE__.": ".mysql_error());

		mysql_select_db($mysql_db)or die('Cannot select db "dtc" !');

		$steps = $step4_form_txt;
	}
}

$main_edito_text = "<blockquote><center><h3>REGISTER</h3></center>
<font size=\"-2\"><i>Exstantem signis multaeque in pondere massae 
ingentem manibus tollit cratera duabus 
infligitque viro; rutilum vomit ille cruorem 
et resupinus humum moribundo vertice pulsat. 
inde Semiramio Polydegmona sanguine cretum 
Caucasiumque Abarin Sperchionidenque Lycetum 
intonsumque comas Helicen Phlegyanque Clytumque 
sternit et exstructos morientum calcat acervos.<br>

Nec Phineus ausus concurrere comminus hosti 
intorquet iaculum, quod detulit error in Idan, 
expertem frustra belli et neutra arma secutum. 
ille tuens oculis inmitem Phinea torvis 
'quandoquidem in partes' ait 'abstrahor, accipe, Phineu, 
quem fecisti, hostem pensaque hoc vulnere vulnus! '
iamque remissurus tractum de corpore telum<br><br>
Note: all fields are mandatory !</i></font>
<br><br>
<center>
$error
$steps $hiddens_parms</form><br>
</center>
</blockquote>";
$edito = skin("iglobal","$main_edito_text","New Account");

$main_content = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr>
	<td width="100% height="1">'.$edito.'</td>
</tr><tr>
	<td></td>
</tr>
</table>';

// Layout left and main content
$content = '<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%">
<tr><td width="1">'.$goodLeft.'</td><td valign="top">'.$main_content.'</td></tr>

</table>';
?>