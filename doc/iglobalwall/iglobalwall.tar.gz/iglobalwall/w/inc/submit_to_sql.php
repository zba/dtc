<?php

function messageToWhitelist($mesg_num){
	global $user_info;
	global $table_validate_url;
	global $table_whitelist;
	if( !isRandomNum($mesg_num) ){
		die("Incorrect message ID!!!");
	}
	$q = "SELECT * FROM $table_validate_url WHERE random_val='".$_REQUEST['msgid']."';";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$n = mysql_num_rows($r);
	if($n != 1)	die("Message ID '".$_REQUEST['msgid']."' not found!");
	$a = mysql_fetch_array($r);

	$mail2add = explode('@',strtolower($a["frombox"]));
	$mailuser2add = $mail2add[0];
	$maildomain2add = $mail2add[1];
	$q = "INSERT INTO $table_whitelist (igw_login,mail_from_user,mail_from_domain,mailbox) VALUES ('".$a["igw_login"]."','$mailuser2add','$maildomain2add','".$a["mailbox"]."');";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());

	$q = "SELECT * FROM $table_validate_url WHERE igw_login='".$a["igw_login"]."' AND mailbox='".$a["mailbox"]."' AND frombox='".$a["frombox"]."';";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$n = mysql_num_rows($r);
	for($i=0;$i<$n;$i++){
		$a = mysql_fetch_array($r);
		$msg = $a["message"];
//		echo $msg;
		$msg_core = strstr($a['message'],"\r\n\r\n");
		$core_size = strlen($msg_core);
		$msg_size = strlen($msg);
		$header = substr($msg,0,$msg_size - $core_size);
		$header2 = strstr($header,"by localhost with SMTP");
		if($header2 != NULL){
			$header3 = strstr($header2,"\n");
			$header4 = substr($header3,1);
		}else{
			$header4 = $header;
		}
		mail($a["igw_login"]."@iglobalwall.com",$a['subject'],$msg_core,$header4);
	}
	$q = "DELETE FROM $table_validate_url WHERE igw_login='".$a["igw_login"]."' AND mailbox='".$a["mailbox"]."' AND frombox='".$a["frombox"]."';";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
}

if( $user_info["loged_in"] == true && $_REQUEST["action"] != "" && isset($_REQUEST["action"])){
if(isset($_REQUEST["addrlink"]) && $_REQUEST["addrlink"] != ""){
	$addr_table = explode('/',$_REQUEST["addrlink"]);
	if(sizeof($addr_table) > 1){
		$edited_mailbox = $addr_table[0];
		$q = "SELECT * FROM $table_mailbox WHERE igw_login='".$user_info["igw_login"]."' AND pop3_email='$edited_mailbox';";
		$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
		$n = mysql_num_rows($r);
		if($n != 1)	die("This mailbox does not seems to be yours!!!");
	}
}
switch($_REQUEST["action"]){
case deletefromsql:
	if(!isRandomNum($_REQUEST["msgid"])){
		die("This is not a msg id!!!");
	}
        $q = "DELETE FROM $table_validate_url WHERE igw_login='".$user_info["igw_login"]."' AND random_val='".$_REQUEST["msgid"]."';";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "remove_mailbox":
	// $_REQUEST["email"]
	// Check if mailbox belongs to user
	$q = "SELECT * FROM $table_mailbox WHERE igw_login='".$user_info["igw_login"]."' AND pop3_email='".$_REQUEST["email"]."';";
	$r = mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$n = mysql_num_rows($r);
	if($n != 1)	die("This mailbox does not seems to be yours!!!");

	$q = "DELETE FROM $table_mailbox WHERE igw_login='".$user_info["igw_login"]."' AND pop3_email='".$_REQUEST["email"]."';";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$q = "DELETE FROM $table_whitelist WHERE igw_login='".$user_info["igw_login"]."' AND mailbox='".$_REQUEST["email"]."';";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	$q = "DELETE FROM $table_validate_url WHERE igw_login='".$user_info["igw_login"]."' AND mailbox='".$_REQUEST["email"]."';";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "edit_pop3":
	// $_REQUEST["igw_email"]
	// $_REQUEST["igw_pop3_srv"]
	// $_REQUEST["igw_pop3_username"]
	// $_REQUEST["igw_pop3_pass"]
	// $_REQUEST["custom_bounce"]
	if($_REQUEST["checkit"] == "yes"){
		$checker = ", checkit='yes'";
	}else{
		$checker = ", checkit='no'";
	}
	if($_REQUEST["autoadd"] == "yes"){
		$autoadd = ", autoadd='yes'";
	}else{
		$autoadd = ", autoadd='no'";
	}
	if($_REQUEST["autodel"] >= 0 && $_REQUEST["autodel"] < 29 && isRandomNum($_REQUEST["autodel"])){
		$autoadd .= ", autodel='".$_REQUEST["autodel"]."' ";
	}
	if(strlen($_REQUEST["custom_bounce"]) > 5){
		if(!strstr($_REQUEST["custom_bounce"],"!!!URL!!!")){
			die("You HAVE to put the text &quot;!!!URL!!!&quot; in your message...");
		}
		$bnc = " bounce_msg='".addslashes($_REQUEST["custom_bounce"])."', ";
	}else{
		$bnc = " bounce_msg='NULL', ";
	}

	if(strlen($_REQUEST["igw_pop3_pass"]) < 3){
		if(!isHostnameOrIP($_REQUEST["igw_pop3_srv"]) || (!isFtpLogin($_REQUEST["igw_pop3_username"]) && !isValidEmail($_REQUEST["igw_pop3_username"])))
			die("Incorrect parameter format for editing pop3 mailbox (server or username format)");
		$q = "UPDATE $table_mailbox SET $bnc pop3_server='".$_REQUEST["igw_pop3_srv"]."', pop3_login='".$_REQUEST["igw_pop3_username"]."'$checker $autoadd WHERE igw_login='".$user_info["igw_login"]."' AND pop3_email='".$_REQUEST["igw_email"]."';";
	}else{
		if(!isHostnameOrIP($_REQUEST["igw_pop3_srv"]) || (!isFtpLogin($_REQUEST["igw_pop3_username"]) && !isValidEmail($_REQUEST["igw_pop3_username"]))||
			!isMailPassword($_REQUEST["igw_pop3_pass"]))
			die("Incorrect parameter format for editing pop3 mailbox");
		$q = "UPDATE $table_mailbox SET $bnc pop3_server='".$_REQUEST["igw_pop3_srv"]."', pop3_login='".$_REQUEST["igw_pop3_username"]."', pop3_pass='".$_REQUEST["igw_pop3_pass"]."'$checker $autoadd WHERE igw_login='".$user_info["igw_login"]."' AND pop3_email='".$_REQUEST["igw_email"]."';";
	}
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "add_pop3_account":
	// $_REQUEST["igw_email"]
	// $_REQUEST["igw_pop3_srv"]
	// $_REQUEST["igw_pop3_username"]
	// $_REQUEST["igw_pop3_pass"]
	if(
		!isValidEmail($_REQUEST["igw_email"]) || 
		!isHostnameOrIP($_REQUEST["igw_pop3_srv"]) ||
		(!isFtpLogin($_REQUEST["igw_pop3_username"]) && 
			!isValidEmail($_REQUEST["igw_pop3_username"])) ||
		!isDTCPassword($_REQUEST["igw_pop3_pass"]))
		die("Incorrect parameter format for adding pop3 mailbox");
	$q = "INSERT INTO $table_mailbox (igw_login,pop3_email,pop3_server,pop3_login,pop3_pass) VALUES ('".$user_info["igw_login"]."','".$_REQUEST["igw_email"]."','".$_REQUEST["igw_pop3_srv"]."','".$_REQUEST["igw_pop3_username"]."','".$_REQUEST["igw_pop3_pass"]."');";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "whitelist_add_email":
	// $_REQUEST["addrlink"] = thomas@goirand.fr%2Fsenders+whitelist
	// $_REQUEST["email"]
	if(!isValidEmail($_REQUEST["email"])) die("Incorrect email format.");

	$mail2add = explode('@',$_REQUEST["email"]);
	$mailuser2add = strtolower($mail2add[0]);
	$maildomain2add = strtolower($mail2add[1]);
	$q = "INSERT INTO $table_whitelist (igw_login,mail_from_user,mail_from_domain,mailbox) VALUES ('".$user_info["igw_login"]."','$mailuser2add','$maildomain2add','$edited_mailbox');";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "whitelist_add_domain":
	// $_REQUEST["addrlink"] = thomas@goirand.fr%2Fsenders+whitelist
	// $_REQUEST["domain"]
	if(!isHostnameOrIP($_REQUEST["domain"])) die("Incorrect domain format.");

	$q = "INSERT INTO $table_whitelist (igw_login,mail_from_user,mail_from_domain,mailbox) VALUES ('".$user_info["igw_login"]."','*','".strtolower($_REQUEST["domain"])."','$edited_mailbox');";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "whitelist_add_to":
	// $_REQUEST["addrlink"]
	// $_REQUEST["address"]
	// =zigo@pplchat.com%2Fsenders+whitelist
	if(!isValidEmail($_REQUEST["address"])) die("Incorrect email format.");
	$q = "INSERT INTO $table_whitelist (igw_login,mail_to,mailbox) VALUES ('".$user_info["igw_login"]."','".$_REQUEST["address"]."','$edited_mailbox');";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "del_whitelist_email":
	// $_REQUEST["addrlink"] = thomas@goirand.fr%2Fsenders+whitelist
	// $_REQUEST["domain_addr"]
	// $_REQUEST["mail_from_user"]
	if(!isValidEmail($_REQUEST["mail_from_user"].'@'.$_REQUEST["domain_addr"])) die("Incorrect email or domain format.");
	$q = "DELETE FROM $table_whitelist WHERE igw_login='".$user_info["igw_login"]."' AND mail_from_user='".$_REQUEST["mail_from_user"]."' AND mail_from_domain='".$_REQUEST["domain_addr"]."' AND mailbox='$edited_mailbox';";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "del_whitelist_domain":
	// $_REQUEST["addrlink"] = thomas@goirand.fr%2Fsenders+whitelist
	// $_REQUEST["domain_addr"]
	if(!isHostnameOrIP($_REQUEST["domain_addr"])) die("Incorrect domain format.");
	$q = "DELETE FROM $table_whitelist WHERE igw_login='".$user_info["igw_login"]."' AND mail_from_user='*' AND mail_from_domain='".$_REQUEST["domain_addr"]."' AND mailbox='$edited_mailbox';";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "del_whitelist_to":
// http://www.iglobalwall.com/index.php?rub=login&
// addrlink=zigo@pplchat.com/senders%20whitelist
// mail_to=debian@list.debian.org
	if(!isValidEmail($_REQUEST["mail_to"])) die("Incorrect email or domain format.");
	$q = "DELETE FROM $table_whitelist WHERE igw_login='".$user_info["igw_login"]."' AND mail_to='".$_REQUEST["mail_to"]."' AND mailbox='$edited_mailbox';";
	mysql_query($q)or die("Cannot execute query: \"$q\" line ".__LINE__." in file ".__FILE__.", mysql said: ".mysql_error());
	break;
case "msg2whitelist":
	messageToWhitelist($_REQUEST['msgid']);
	break;
case "deleteall_unverified":
	if(!isValidEmail($_REQUEST["addrlink"]))	die("This is not a valid email address.");
	$q = "DELETE FROM validate_url WHERE igw_login='".$user_info["igw_login"]."' AND mailbox='".$_REQUEST["addrlink"]."';";
	break;
}
}

?>
