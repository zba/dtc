<?php

//////////////////////////////////////////////////
// DROP DOWN WITH IE STYLE TREE MENU GENERATION //
//////////////////////////////////////////////////
$ietype_menu_img_nbr=0;
$ietype_menu_recurs_level=0;
$treesign_array=array();
$treeAddrsArray = array();

$alt_signs = "";

// Calculate a string reprensentative of the
// tree cells to draw. Exemple of ret values : none/vline/endtree/hline
function makeTreeGfxUrl($array,$nbr){
	global $alt_signs;
	$alt_signs = "";
	for($i=0;$i<=$nbr;$i++){
		if($i > 0){
			$ret .= "/";
		}
		$plop = $array[$i];
		$ret .= $plop;
		if($plop == "none"){
			$alt_signs .= "";
		}else if($plop == "vline"){
			$alt_signs .= "-";
		}else if($plop == "tree"){
			$alt_signs .= "|";
		}else if($plop == "endtree"){
			$alt_signs .= "`";
		}else if($plop == "hline"){
			$alt_signs .= "-";
		}else if($plop == "minus"){
			$alt_signs .= "-";
		}else if($plop == "plus"){
			$alt_signs .= "+";
		}
	}
	return $ret;
}

// Calculate current entry full adresse
function calculateCurEntryAddr($entry){
	global $ietype_menu_recurs_level;
	global $treeAddrsArray;

	$entrylink = $entry["link"];
	$treeAddrsArray[$ietype_menu_recurs_level] = $entrylink;
	for($i=0;$i<=$ietype_menu_recurs_level;$i++){
		if($i>0){
			$ret .= "/";
		}
		$ret .= $treeAddrsArray[$i];
	}
	return $ret;
}

function getCacheImageURL($text,$color,$arbo){
	$cache = str_replace("/","_",$text.$color.$arbo) . ".png";
	if(file_exists("imgcache/$cache")){
		return "imgcache/$cache";
	}else{
		return "inc/img.php?text=$text&color=$color&link=$arbo";
	}
}

function makeIetypeMenu($menu,$curent_addr,$self_link,$link_name){
	global $ietype_menu_img_nbr;
	global $ietype_menu_recurs_level;
	global $link;
	global $treesign_array;

	global $alt_signs;
	global $dtc_use_text_menu;

	// Get an array out of the current selected addresse
	$selected = explode("/",$curent_addr);


	// For each item of current level of the tree
	$nbr_menu_entry = sizeof($menu);
	for($i=0;$i<$nbr_menu_entry;$i++){
		$entry = $menu[$i];
		$text = $entry["text"];

		// Calculate current addresse
		$entrylink = calculateCurEntryAddr($entry);

		// Calculate the href link that the menu entry point to
		$alink = "<a href=\"$self_link&$link_name=$entrylink\">";

		// Is it a drop down entry with plus/minus lign ?
		if($entry["type"] == "menu"){
			if($entry["text"] == $selected[$ietype_menu_recurs_level]){
				$treesign_array[$ietype_menu_recurs_level] = "minus";
				$arbo = makeTreeGfxUrl($treesign_array,$ietype_menu_recurs_level);
				$image_source = getCacheImageURL($text,1,$arbo);
				if($dtc_use_text_menu == "no"){
					$ret .= "$alink<img border=\"0\" alt=\"-".$entry["text"]."\" src=\"$image_source\"></a><br>";
				}else{
					$ret .= $alink." -".$entry["text"]."</a><br>";
				}

				$treesign_array[$ietype_menu_recurs_level] = "tree";

				// Recurse inside the menu because it is selected

				$ietype_menu_recurs_level += 1;
				$ret .= makeIetypeMenu($entry["sub"],$curent_addr,$self_link,$link_name);
				$ietype_menu_recurs_level -= 1;
			}else{
				// Menu is not selected, so just draw it normaly
				$treesign_array[$ietype_menu_recurs_level] = "plus";
				$arbo = makeTreeGfxUrl($treesign_array,$ietype_menu_recurs_level);
				$image_source = getCacheImageURL($text,0,$arbo);
				$image_rolover = getCacheImageURL($text,1,$arbo);
				if($dtc_use_text_menu == "no"){
					$rolovered = addImageToPreloads($image_rolover);
					$ret .= "$alink<img border=\"0\" name=\"$rolovered\"
src=\"$image_source\" alt=\"$alt_signs".$entry["text"]."\" 
onmouseover=\"$rolovered.src='$image_rolover'\" onmouseout=\"$rolovered.src='$image_source'\"></a><br>";
				}else{
					$ret .= "$alink".$alt_signs.$entry["text"]."</a><br>";
				}
			}
		}else if($entry["type"] == "link"){
			// Calculate the sign to put at the left of the entry (plus, minus, or none)
			if($ietype_menu_recurs_level > 0){
				if($i == $nbr_menu_entry-1){
					$mysign="endtree";
				}else{
					$mysign="tree";
				}
			}else if($entry["type"] == "link"){
				$mysign="";
			}
			if($ietype_menu_recurs_level > 0){
				$treesign_array[$ietype_menu_recurs_level] = "hline";
				$treesign_array[$ietype_menu_recurs_level-1] = "$mysign";
				if($ietype_menu_recurs_level > 1){
					$treesign_array[$ietype_menu_recurs_level-2] = "vline";
				}
			}else{
				$treesign_array[$ietype_menu_recurs_level] = "none";
			}
			$arbo = makeTreeGfxUrl($treesign_array,$ietype_menu_recurs_level);
			if($entry["text"] == $selected[$ietype_menu_recurs_level]){
				$image_source = getCacheImageURL($text,1,$arbo);
				if($dtc_use_text_menu == "no"){
					$ret .= "$alink<img border=\"0\" alt=\"$alt_signs".$entry["text"]."\" src=\"$image_source\"></a><br>";
				}else{
					$ret .= "$alink".$alt_signs.$entry["text"]."</a><br>";
				}
			}else{
				$image_source = getCacheImageURL($text,0,$arbo);
				$image_rolover = getCacheImageURL($text,1,$arbo);
				if($dtc_use_text_menu == "no"){
					$rolovered = addImageToPreloads($image_rolover);
					$ret .= "$alink<img border=\"0\" name=\"$rolovered\"
src=\"$image_source\" alt=\"$alt_signs".$entry["text"]."\" 
onmouseover=\"$rolovered.src='$image_rolover'\" onmouseout=\"$rolovered.src='$image_source'\"></a><br>";
				}else{
					$ret .= "$alink".$alt_signs.$entry["text"]."</a><br>";
				}
			}
			if($mysign=="endtree"){
				$treesign_array[$ietype_menu_recurs_level] = "none";
			}
		}
	}

	return $ret;
}

function makeTreeMenu($menu,$selected,$self_link,$link_name){
	global $ietype_menu_img_nbr;
	global $ietype_menu_recurs_level;
	global $treesign_array;
	global $treeAddrsArray;

	global $dtc_use_text_menu;

	$ietype_menu_img_nbr=0;
	$ietype_menu_recurs_level=0;
	$treesign_array=array();
	$treeAddrsArray = array();

	if($dtc_use_text_menu == "yes"){
		$ret .= "<pre><b><font size=\"+1\">";
	}
	$ret .= makeIetypeMenu($menu,$selected,$self_link,$link_name);
	if($dtc_use_text_menu == "yes"){
		$ret .= "</font></b></pre>";
	}
	return $ret;
}


?>
