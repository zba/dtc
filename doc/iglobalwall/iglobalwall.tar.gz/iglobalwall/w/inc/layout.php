<?php

function layLeftRightFrame($left,$right,$which_resize){
	if($which_resize=="right"){
		$left_size = '';
		$right_size = '100%';
	}else{
		$left_size = '100%';
		$right_size = '';
	}
	return "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"100%\">
<tr><td valign=\"top\" height=\"100%\" width=\"$left_size\">$left</td>
<td valign=\"top\" width=\"$right_size\">$right</td></tr></table>
";
}

function layTopBottomFrame($top,$bottom,$which_resize){
	if($which_resize!="top"){
		$left_size = '1';
		$right_size = '100%';
	}else{
		$left_size = '100%';
		$right_size = '1';
	}
	return "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"100%\">
<tr><td width=\"100%\" height=\"$left_size\" valign=\"top\">$top</td></tr>
<tr><td width=\"100%\" height=\"$right_size\" valign=\"top\">$bottom</td></tr></table>
";
}

function layTableCells($html_array,$num_colone){
	global $globspace;
	global $globpadd;
	$num_ligne = sizeof($html_array) / $num_colone;
	$width = 100 / $num_colone;
	$height = 100 / $num_ligne;
	$out = "
<table width=\"100%\" height=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
";
	for($i=0;$i<$num_ligne;$i++){
		$out .= "
	<tr>";
		for($j=0;$j<$num_colone;$j++){
			$in = $html_array[$i*$num_colone+$j];
			$out.= "<td width=\"$width%\" height=\"$height%\">
	$in</td>
";
		}
		$out .= "
	</tr>";
	}
	$out .= "
</table>
";
	return $out;
}

function verticalLayout($cells){
	$nbrCell = sizeof($cells);
	$ret = "
<table boder=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"100%\">";
	for($i=0;$i<$nbrCell;$i++){
		$cell = $cells[$i];
		$ret .= "
<tr><td width=\"100%\" height=\"1\" valign=\"top\">$cell</td></tr>";
	}
	$ret .= "<tr><td width=\"100%\" height=\"100%\" valign=\"top\">&nbsp;</td></tr></table>";
	return $ret;
}

?>
