<?php

$table_mailbox = "mailbox";
$table_users = "users";
$table_whitelist = "whitelist";
$table_validate_url = "validate_url";

?>