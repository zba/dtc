<?php

$normalUserMaxLevel = 50;

session_register("user_info");

function fetchUser(){
	global $user_info;
	global $table_users;

	$query = "SELECT * FROM $table_users WHERE u_login ='".$user_info->login."' AND u_pass='".$user_info->pass."';";
	$result = mysql_query($query) or die("Cannot query \"$query\" !!!".mysql_error());
	$num_rows = mysql_num_rows($result);
	if($num_rows != 1){
		die("Cannot fetch user : ".$user_info->login." !!!");
	}
	$user_info->sqlInfo = mysql_fetch_array($result);
}

function userLogin(){
	// Result in the following request :
	// http://127.0.0.1/guns/index.php?rub=login&sousrub=&u_login=zigo&u_pass=zigo&u_pass2=zigo&u_email=tg@witness.fr&u_addr=34+rue+camille+pelletant&u_addr2=-&u_zipcode=92+300&u_city=LEVALOIS+PERET&u_country=France&u_tel=%2B33+%280%29+1+47+27+92+50&u_fax=%2B33+%280%29+1+47+37+18+79&submit=Ok
	global $SERVER_NAME;
	global $PHP_SELF;
	global $table_users;
	global $rub;
	global $sousrub;
	global $operation;
	global $u_id;
	global $u_login;
	global $u_pass;
	global $u_email;
	global $u_addr;
	global $u_addr2;
	global $u_zipcode;
	global $u_city;
	global $u_country;
	global $u_tel;
	global $u_fax;
	global $u_level;
	global $user_info;
	global $page;
	global $HTTP_SERVER_VARS;

	$login_form = "
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"1\"><tr>
<td width=\"50%\" valign=\"top\"><form action=\"$PHP_SELF\">
	<input type=\"hidden\" name=\"rub\" value=\"$rub\">
	<input type=\"hidden\" name=\"sousrub\" value=\"$sousrub\">
	<input type=\"hidden\" name=\"operation\" value=\"login\">
	Veuillez vous identifier :<br><br>
	<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"1\"><tr>
	<td align=\"right\">Login :</td><td><input type=\"text\" name=\"u_login\" value=\"\"></td></tr>
	<tr><td align=\"right\">Password :</td><td><input type=\"password\" name=\"u_pass\" value=\"\"></td></tr>
	<tr><td>&nbsp;</td><td><input type=\"submit\" name=\"submit\" value=\"Ok\"></td></tr></form>
	<tr><td colspan=\"2\"><br>Mot de passe boubli� :</td></tr>
	<tr><form action=\"$PHP_SELF\"><td align=\"right\">
	<input type=\"hidden\" name=\"operation\" value=\"forgot_pass\">
	Login :</td><td><input type=\"password\" name=\"u_pass\" value=\"\"></td></tr>
	<tr><td>&nbsp;</td><td><input type=\"submit\" name=\"submit\" value=\"Ok\"></td></tr></form>
	</table>
	</td>
<td><td width=\"50%\" align=\"left\" valign=\"top\"><form action=\"$PHP_SELF\" method=\"post\">
	<input type=\"hidden\" name=\"operation\" value=\"newuser\">
	<input type=\"hidden\" name=\"sousrub\" value=\"$sousrub\">
	<input type=\"hidden\" name=\"rub\" value=\"$rub\">
	Ouvrir un nouveau compte :<br><br>
	<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"1\"><tr>
	<td align=\"right\">Login :</td><td><input type=\"text\" name=\"u_login\" value=\"$u_login\"></td></tr>
	<tr><td align=\"right\">Password :</td><td><input type=\"password\" name=\"u_pass\" value=\"\"></td></tr>
	<tr><td align=\"right\">Password (confirm) :</td><td><input type=\"password\" name=\"u_pass2\" value=\"\"></td></tr>
	<tr><td align=\"right\">Email :</td><td><input type=\"text\" name=\"u_email\" value=\"\"></td></tr>
	<tr><td align=\"right\">Addresse :</td><td><input type=\"text\" name=\"u_addr\" value=\"\"></td></tr>
	<tr><td align=\"right\">Addresse (ligne 2) :</td><td><input type=\"text\" name=\"u_addr2\" value=\"\"></td></tr>
	<tr><td align=\"right\">Code postal :</td><td><input type=\"text\" name=\"u_zipcode\" value=\"\"></td></tr>
	<tr><td align=\"right\">Ville :</td><td><input type=\"text\" name=\"u_city\" value=\"\"></td></tr>
	<tr><td align=\"right\">Pays :</td><td><input type=\"text\" name=\"u_country\" value=\"\"></td></tr>
	<tr><td align=\"right\">T�l�phone :</td><td><input type=\"text\" name=\"u_tel\" value=\"\"></td></tr>
	<tr><td align=\"right\">Fax :</td><td><input type=\"text\" name=\"u_fax\" value=\"\"></td></tr>
	<tr><td align=\"right\">Vous �tes :</td><td><select name=\"u_level\">
	<option value=\"50\">Un particulier</option>
	<option value=\"100\">Une entreprise partenaire</option>
	</select></td></tr>
	<tr><td>&nbsp;</td><td><input type=\"submit\" name=\"submit\" value=\"Ok\"></td></tr></table>
	</form></td>
</tr></table>
";
	if(!isset($operation) || $operation == ""){
		// Add the title to it
		$thisnews = $login_form;
	}else{
		if($operation == "newuser"){
			if(!isset($u_login)||!isset($u_pass)||!isset($u_email)||!isset($u_addr)||!isset($u_zipcode)||!isset($u_city)||!isset($u_country)||!isset($u_tel)||!isset($u_fax)||!isset($u_level)||
				$u_login == "" || $u_pass == "" || $u_email == "" || $u_addr == "" || $u_zipcode == "" || $u_city == "" || $u_country == "" || $u_tel == "" || $u_fax == "" || $u_level == "" ){
				$thisnews = "Vous n'avez pas remplis tout le formulaire.<br><br>$login_form";
			}
			if($u_pass != $u_pass2){
				$thisnews = "Vos mots de passe ne correspondent pas.";
			}else{
				$query = "INSERT INTO $table_users (u_id,u_login,u_pass,u_email,u_addr,u_addr2,u_zipcode,u_city,u_country,u_tel,u_fax,u_level,u_flags)
				VALUES ('','$u_login','$u_pass','$u_email','$u_addr','$u_addr2','$u_zipcode','$u_city','$u_country','$u_tel','$u_fax','$u_level','w');";
				if($u_level <= 50){
					$user_info->login = $u_login;
					$user_info->pass = $u_pass;
					$user_info->login_ok_flag = true;
					fetchUser();
					$thisnews = "Votre �tes maintenant identifi�.";
				}else{
					$thisnews = "Votre demande a �t� enregistr�, et sera v�rifi� sous peu. Un email vous sera envoy� d�s que votre compte sera
					valid� par le webmaster.<br><br>
					<a href=\"$PHP_SELF\">RETOUR AU SITE</a>";
				}
			}
		}else if($operation == "login"){
			$query = "SELECT * FROM $table_users WHERE u_login='$u_login' AND u_pass='$u_pass';";
			$result = mysql_query($query) or die("Cannot query \"$query\" !!!".mysql_error());
			$num_rows = mysql_num_rows($result);
			if($num_rows != 1){
				$thisnews = "L'utilisateur n'a pas �t� trouv�. Rentrez des informations valides.<br><br>$login_form";
			}else{
				$user_info->login = $u_login;
				$user_info->pass = $u_pass;
				$user_info->login_ok_flag = true;
				fetchUser();
				$thisnews = "Votre �tes maintenant identifi�. Attendez le refresh dans 5 secondes, ou cliquez <a href=\"$PHP_SELF?rub=login\">ici</a> pour d�marer l'administration.";
				$page->meta_customs .= '<META HTTP-EQUIV="Refresh" CONTENT="5; URL='.$HTTP_SERVER_VARS['REQUEST_URI'].'">';
			}
		}else if($operation == "forgot_pass"){
			$thisnews = "[EN CONSTRUCTION]<br>
			Un email contenant votre mot de passe a �t� envoy� � votre addresse email.<br><br>
			Si vous ne pouvez lire votre boite et que vous d�sirez quand m�me acc�der � votre compte, veuillez �crire au
			<a href=\"mailto:webmaster\@".$SERVER_NAME."\">webmaster</a><br>
			[EN CONSTRUCTION]";
		}
	}
	return $thisnews;
}

function userEdit(){
	global $SERVER_NAME;
	global $PHP_SELF;
	global $table_users;
	global $table_partners;
	global $rub;
	global $sousrub;
	global $operation;
	global $user_info;
	global $action;
	global $partnerid;
	$out = '
	<input type="hidden" name="operation" value="updateuser">
	<input type="hidden" name="sousrub" value="'.$sousrub.'">
	<input type="hidden" name="rub" value="'.$rub.'">
	<u><b>Vos informations :</b></u><br><br>

	<table border="0" cellspacing="0" cellpadding="2" height="1"><form action="'.$PHP_SELF.'"><tr>
		<input type="hidden" name="rub" value="'.$rub.'">
		<input type="hidden" name="sousrub" value="'.$sousrub.'">
		<input type="hidden" name="sqlcmd" value="edit_user_personal_info">
		<input type="hidden" name="u_id" value="'.$user_info->sqlInfo["u_id"].'">
		<td>
			<table border="0" cellspacing="2" cellpadding="0" height="1">
				<tr><td align="right">Login :</td>
					<td>'.$user_info->sqlInfo["u_login"].'</td></tr>
				<tr><td align="right">Email :</td>
					<td><input type="text" name="u_email" value="'.$user_info->sqlInfo["u_email"].'"></td></tr>
				<tr><td align="right">T�l�phone :</td>
					<td><input type="text" name="u_tel" value="'.$user_info->sqlInfo["u_tel"].'"></td></tr>
				<tr><td align="right">Fax :</td>
					<td><input type="text" name="u_fax" value="'.$user_info->sqlInfo["u_fax"].'"></td></tr>
				<tr><td>&nbsp;</td>
					<td><input type="submit" name="submit" value="Ok"></td></tr>
			</table>
		</td><td>
			<table border="0" cellspacing="2" cellpadding="0" height="1">
				<tr><td align="right">Addresse :</td>
					<td><input type="text" name="u_addr" value="'.$user_info->sqlInfo["u_addr"].'"></td></tr>
				<tr><td align="right">Addresse (ligne 2) :</td>
					<td><input type="text" name="u_addr2" value="'.$user_info->sqlInfo["u_addr2"].'"></td></tr>
				<tr><td align="right">Code postal :</td>
					<td><input type="text" name="u_zipcode" value="'.$user_info->sqlInfo["u_zipcode"].'"></td></tr>
				<tr><td align="right">Ville :</td>
					<td><input type="text" name="u_city" value="'.$user_info->sqlInfo["u_city"].'"></td></tr>
				<tr><td align="right">Pays :</td>
					<td><input type="text" name="u_country" value="'.$user_info->sqlInfo["u_country"].'"></td></tr>
			</table>
	</td></tr></form></table>

	<br><br><u><b>Changement de mot de passe</b></u><br><br>
	<table border="0" cellspacing="2" cellpadding="0" width="360" height="1"><form action="'.$PHP_SELF.'">
		<input type="hidden" name="rub" value="'.$rub.'">
		<input type="hidden" name="sousrub" value="'.$sousrub.'">
		<input type="hidden" name="sqlcmd" value="change_password">
		<input type="hidden" name="u_id" value="'.$user_info->sqlInfo["u_id"].'">
		<tr><td align="right">Votre ancien mot de passe :</td>
			<td><input type="password" name="u_old_pass" value=""></td></tr>
		<tr><td align="right">Nouveau mot de passe :</td>
			<td><input type="password" name="u_pass" value=""></td></tr>
		<tr><td align="right">Nouveau mot de passe (confirmation) :</td>
			<td><input type="password" name="u_pass2" value=""></td></tr>
		<tr><td>&nbsp;</td>
			<td><input type="submit" name="submit" value="Ok"></td></tr></form>
	</table>';

	$query = "SELECT * FROM $table_partners WHERE owner='".$user_info->login."';";
	$result = mysql_query($query) or die("Cannot query \"$query\" !!!".mysql_error());
	$num_rows = mysql_num_rows($result);
	$out .=	'<br><br><u><b>Partenaires que vous administrez :</b></u><br><br>';

	for($i=0;$i<$num_rows;$i++){
		$row = mysql_fetch_array($result);
		if($i > 0)
			$out .= " - ";
		$out .= "<a href=\"$PHP_SELF?rub=$rub&sousrub=$sousrub&action=edit_partner&partnerid=".$row["id"]."\">".$row["name"]."</a>";
	}
	$out .= "<br><br><a href=\"$PHP_SELF?rub=$rub&sousrub=$sousrub&action=new_partner\">Nouveau partenaria</a>";

	if($action == "new_partner"){
		return "	<u><b>Nouveau partenaria :</b></u><br><br>

<form action=\"$PHP_SELF\" method=\"post\">
<table width=\"100%\"><tr><td valign=\"top\">
<input type=\"hidden\" name=\"new_partner\" value=\"yes\">
Nom de votre soci�t� / marque / journal :<br>
<input type=\"text\" name=\"new_name\" value=\"\"><br>
URL de votre site web :<br>
<input type=\"text\" name=\"new_siteurl\" value=\"http://\"><br>
Type de votre soci�t� :<br>
<select name=\"new_type\">
<option value=\"mag\">Magasine</option>
<option value=\"shop\">Boutique</option>
<option value=\"travel\">Voyage</option>
</select><br>
Image repr�sentant votre soci�t� :<br>
<input type=\"file\" name=\"new_image\">
</td><td valign=\"top\">
Num�ro de rue :<br>
<input type=\"text\" name=\"new_streetnum\" value=\"\"><br>
Adresse :<br>
<input type=\"text\" name=\"new_addr\" value=\"\"><br>
Ville :<br>
<input type=\"text\" name=\"new_city\" value=\"\"><br>
Code postal :<br>
<input type=\"text\" name=\"new_zipcode\" value=\"\"><br>
R�gion ou �tat, le cas �ch�ant :<br>
<input type=\"text\" name=\"new_state\" value=\"\"><br>
</td><td valign=\"top\">
T�l�phone :<br>
<input type=\"text\" name=\"new_phone\" value=\"\"><br>
Fax :<br>
<input type=\"text\" name=\"new_fax\" value=\"\"><br>
Email :<br>
<input type=\"text\" name=\"new_email\" value=\"\"><br>
<input type=\"submit\" name=\"submit\" value=\"Ok\">
</form></td></tr></table>
		";
	}else if($action == "edit_partner"){
		$query = "SELECT * FROM $table_partners WHERE id='$partnerid' AND owner='".$user_info->login."';";
		$result = mysql_query($query) or die("Cannot query \"$query\" !!!".mysql_error());
		$num_rows = mysql_num_rows($result);
		if($num_rows != 1)
			die("Cannot fetch partner for editing");
		$row = mysql_fetch_array($result);
		return '	<u><b>Edition d\'un partenaria :</b></u><br><br>
		
	<table border="0" cellspacing="0" cellpadding="2" height="1"><tr>
		<form action="'.$PHP_SELF.'" method="post" ENCTYPE="multipart/form-data">
		<input type="hidden" name="rub" value="'.$rub.'">
		<input type="hidden" name="sousrub" value="'.$sousrub.'">
		<input type="hidden" name="action" value="'.$edit_partner.'">
		<input type="hidden" name="sqlcmd" value="edit_one_partner">
		<td>
			<table border="0" cellspacing="2" cellpadding="0" height="1">
				<tr><td align="right">Nom du partenaire :</td>
					<td><input type="text" size="32" name="name" value="'.$row["name"].'"></td></tr>
				<tr><td align="right">URL du site web :</td>
					<td><input type="text" size="32" name="siteurl" value="'.$row["siteurl"].'"></td></tr>
				<tr><td align="right">Email :</td>
					<td><input type="text" size="32" name="mail" value="'.$row["mail"].'"></td></tr>
				<tr><td align="right">Image :</td>
					<td><input type="file" size="32" name="image_file" value="'.$row["imgpath"].'"></td></tr>
				<tr><td align="right">Type de soci�t� :</td>
					<td>'.$row["type"].'</td></tr>
				<tr><td align="right">Adresse :</td>
					<td><input type="text" size="32" name="addr" value="'.$row["addr"].'"></td></tr>
				<tr><td align="right"><input type="submit" name="delete" value="del"></td>
					<td><input type="submit" name="submit" value="Ok" default></td></tr>
			</table>
		</td><td valign="top">
			<table border="0" cellspacing="2" cellpadding="0" height="1">
				<tr><td align="right">Addresse (ligne 2) :</td>
					<td><input type="text" size="32" name="u_addr2" value="'.$row["addr2"].'"></td></tr>
				<tr><td align="right">Code postal :</td>
					<td><input type="text" size="32" name="u_zipcode" value="'.$row["zipcode"].'"></td></tr>
				<tr><td align="right">Ville :</td>
					<td><input type="text" size="32" name="u_city" value="'.$row["city"].'"></td></tr>
				<tr><td align="right">Pays :</td>
					<td><input type="text" size="32" name="u_country" value="'.$row["country"].'"></td></tr>
				<tr><td align="right">Tel :</td>
					<td><input type="text" size="32" name="phone" value="'.$row["phone"].'"></td></tr>
				<tr><td align="right">Fax :</td>
					<td><input type="text" size="32" name="fax" value="'.$row["fax"].'"></td></tr>
			</table>
	</td></tr></form></table>
		';
	}else{
		return $out;
	}
}

?>
