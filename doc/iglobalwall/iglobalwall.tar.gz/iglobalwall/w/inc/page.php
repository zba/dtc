<?php

class page{
	var $page_title;
	var $meta_charset;
	var $meta_description;
	var $meta_keywords;
	var $meta_owner_email;
	var $meta_autor;

	var $meta_customs;

	var $javascirpt;

	var $stylesheets;

	var $lang;

	function init(){
		global $charset;
		$this->page_title = "The Ultimate ANTI-SPAM Service!";
		$this->meta_charset = $charset;
	}

	function make($content){
		$zePreloads .= makePreloads();
		global $skinCssString;
		$ret = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>'.$this->page_title.'</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset='.$this->meta_charset.'">
<META NAME="DESCRIPTION" CONTENT="'.$this->meta_description.'">
<META NAME="KEYWORDS" lang="'.$this->lang.'" CONTENT="'.$this->meta_keywords.'">
<META NAME="OWNER" CONTENT="'.$this->meta_owner_email.'">
<META NAME="AUTHOR" CONTENT="'.$this->meta_autor.'Thomas GOIRAND">
<META HTTP-EQUIV="CONTENT-LANGUAGE" CONTENT="french">
<META NAME="ROBOTS" CONTENT="index,follow">
<META NAME="REVISIT-AFTER" CONTENT="7 days">
'.$this->meta_customs.'
'.$skinCssString.'
<link rel="STYLESHEET" type="text/css" href="gfx/all.css">
'.$zePreloads.'
<script language="javascript">
<!--
'.$this->javascirpt.'
// -->
</script>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" bgcolor="#FFFFFF">
'.$content.'
<font size="-2"><center>
<pre>(c) 2004 <a
href="http://www.iglobalnetworks.com">iGlobalNetworks.com</a>
and <a href="http://www.gplhost.com">GPLHost.com</a></pre>
</center></font></body>
</html>
';
		echo $ret;
	}
}


?>