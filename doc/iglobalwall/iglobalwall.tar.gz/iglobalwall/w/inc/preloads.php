<?php

// Our globals
$preloads = array();
$nbrPreloadedImage = 0;
$imagePrefix = "rolloverImg";
///////////////////////////////////////////////////////////////////////////////////////////////
// Add a "preload image" in the header javascripts, and return the name of the created image //
// for adding the onmouseover() and onmouseout() javascript stuff                            //
///////////////////////////////////////////////////////////////////////////////////////////////
function addImageToPreloads($imagePath){
	global $preloads;
	global $nbrPreloadedImage;
	global $imagePrefix;

	$preloads[] = $imagePath;
	$nbrPreloadedImage++;
	return "$imagePrefix$nbrPreloadedImage";
}
//////////////////////////////////////////////
// Make the javascript for preloaded images //
//////////////////////////////////////////////
function makePreloads(){
	global $preloads;
	global $nbrPreloadedImage;
	global $imagePrefix;
	$java_script = "<SCRIPT LANGUAGE=\"JavaScript\">
<!-- Begin\n";
	for($i=0;$i<$nbrPreloadedImage;$i++){
		$imgNum = $i+1;
		$src = $preloads[$i];
		$java_script .= "
$imagePrefix$imgNum = new Image();
$imagePrefix$imgNum.src = \"$src\";
";
	}
	$java_script .= "\n// End --></script>\n";
	return $java_script;
}
/////////////////////////////////////////////////////////////////////////////
// Make a rollover image out of two path and add it to rollover collection //
/////////////////////////////////////////////////////////////////////////////
function makeImgRollover($normal,$rollover,$alt){
	if($rollover != ""){
		$imgName = addImageToPreloads($rollover);
		$rolloverScript = " name=\"$imgName\" onmouseover=\"$imgName.src='$rollover'\" onmouseout=\"$imgName.src='$normal'\" ";
	}
	return "<img src=\"$normal\" $rolloverScript border=\"0\" alt=\"$alt\">";
}


?>
