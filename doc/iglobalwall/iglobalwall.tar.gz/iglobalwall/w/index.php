<?php

session_name("wallid");

include("inc/lang.php");
include("strings.php");
include("inc/dbconnect.php");
include("inc/skinLib.php");
include("inc/preloads.php");
include("inc/layout.php");
include("pagetop.php");
include("inc/page.php");
include("inc/table_names.php");
include("inc/dtc_functions.php");
include("inc/submit_to_sql.php");
include("inc/dtc_tree_menu.php");

$page = new page();
$page->init();

$rub = $_REQUEST["rub"];
$sousrub = $_REQUEST["sousrub"];

if(!$rub)
	$rub = "defaut";
$rub_plus_extention = $rub.".php";


if(!file_exists("rubs/$rub_plus_extention")){
	include("rubs/construction.php");
}else{
	include("rubs/$rub_plus_extention");
}

$pageRight = layTopBottomFrame(pageTop(),$content,"bottom"); 
$page->make($pageRight);

?>