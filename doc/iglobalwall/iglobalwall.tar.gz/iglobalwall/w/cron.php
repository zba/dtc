<?php

session_name("wallid");

include("inc/lang.php");
include("strings.php");
include("inc/dbconnect.php");
include("inc/skinLib.php");
include("inc/preloads.php");
include("inc/layout.php");
include("pagetop.php");
include("inc/page.php");
include("inc/table_names.php");
include("inc/dtc_functions.php");
include("inc/submit_to_sql.php");
include("inc/dtc_tree_menu.php");

$q = "SELECT * FROM $table_users ORDER BY igw_login";
$r = mysql_query($q)or die("Cannot query \"$q\" line: ".__LINE__." file: ".__FILE__." server said: ".mysql_error());
$n = mysql_num_rows($r);
for($i=0;$i<$n;$i++){
	$u = mysql_fetch_array($r);
	echo "Retriving: ".$u["igw_login"]."\n";
	$q2 = "SELECT * FROM $table_mailbox WHERE igw_login='".$u["igw_login"]."' AND checkit='yes' ORDER BY pop3_email";
	$r2 = mysql_query($q2)or die("Cannot query \"$q2\" line: ".__LINE__." file: ".__FILE__." server said: ".mysql_error());
	$n2 = mysql_num_rows($r2);
	for($j=0;$j<$n2;$j++){
		$m = mysql_fetch_array($r2);
		$cmd_fetchmail = "/usr/bin/fetchmail -f - -v --auth password --smtpname ".
			$u["igw_login"]."@iglobalwall.com -p pop3 -a -t 90".
			" -b 64 -e 64 -D iglobalwall.com --tracepolls".
			" -u ".$m["pop3_login"]." ".$m["pop3_server"]."";
		$fetchmailrc = 'poll "'.$m["pop3_server"].'" proto pop3 user "'.$m["pop3_login"].'" password "'.$m["pop3_pass"]."\"\n";
//		echo $cmd_fetchmail."\n";
//		echo $m["pop3_pass"];

		$pipe = popen($cmd_fetchmail,"w");
		fwrite($pipe, $fetchmailrc);
		pclose($pipe);

		if($m["autodel"] > 0 && $m["autodel"] < 29){
			$date = date("Y-m-d",time()-(3600*24*($m["autodel"]+1)));
			$q3 = "DELETE FROM validate_url WHERE igw_login='".$u["igw_login"]."' && mailbox='".$m["pop3_email"]."' && date < $date;";
			echo "Deleting before $date: $q3\n";
			mysql_query($q3)or die("Cannot query \"$q3\" line: ".__LINE__." file: ".__FILE__." server said: ".mysql_error());
		}
	}
}

?>