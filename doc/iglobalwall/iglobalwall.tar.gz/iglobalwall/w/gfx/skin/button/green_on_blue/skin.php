<?php

$skinTable[] = array(
	"skinName" => 'button/green_on_blue',
	"skinCss" => 'skin.css',
	"functionCode" => '
	$skinpath = "$skinGeneralPath/$skinpath";

	if($title != "selected"){
		return "
<table width=\"1\" height=\"1\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
<tr>
	<td width=\"1\" height=\"1\"><img src=\"$skinpath/start.gif\"></td>
	<td background=\"$skinpath/back.gif\" style=\"white-space: nowrap\" nowrap id=\"buttonGreenOnBlue\"><a href=\"$title\">$content</a></td>
	<td width=\"1\"><img src=\"$skinpath/end.gif\"></td>
</tr>
</table>
";
	}else{
		return "
<table width=\"1\" height=\"1\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
<tr>
	<td width=\"1\" height=\"1\"><img src=\"$skinpath/start_s.gif\"></td>
	<td background=\"$skinpath/back_s.gif\" style=\"white-space: nowrap\" nowrap id=\"buttonGreenOnBlue\">$content</a></td>
	<td width=\"1\"><img src=\"$skinpath/end_s.gif\"></td>
</tr>
</table>
";
	}
'
	);

?>
