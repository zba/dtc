<?php

$skinTable[] = array(
	"skinName" => 'blue',
	"skinCss" => 'skin.css',
	"functionCode" => '
	$skinpath = "$skinGeneralPath/$skinpath";

	return "
<table width=\"100%\" height=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
<tr>
	<td width=\"1\"><img src=\"$skinpath/coin01.gif\"></td>
	<th background=\"$skinpath/trait01.gif\" valign=\"center\" style=\"white-space: nowrap\" nowrap id=\"skinBlueTitle\">$title</td>
	<td width=\"1\"><img src=\"$skinpath/inter.gif\" border=\"0\"></td>
	<td width=\"100%\" background=\"$skinpath/trait02.gif\"><img src=\"$skinpath/trait02.gif\" border=\"0\"></td>
	<td width=\"1\"><img src=\"$skinpath/coin02.gif\" border=\"0\"></td>
</tr>
<tr>
	<td width=\"1\" background=\"$skinpath/trait05.gif\" height=\"100%\"><img src=\"$skinpath/trait05.gif\" border=\"0\"></td>
	<td width=\"100%\" colspan=\"3\" background=\"$skinpath/fond01.gif\" valign=\"top\" id=\"skinBlueContent\">$content</td>
	<td width=\"1\" background=\"$skinpath/trait03.gif\"><img src=\"$skinpath/trait03.gif\" border=\"0\"></td>
</tr>
<tr>
	<td width=\"1\"><img src=\"$skinpath/coin04.gif\"></td>
	<td width=\"100%\" background=\"$skinpath/trait04.gif\" colspan=\"3\"><img src=\"$skinpath/trait04.gif\" border=\"0\"></td>
	<td width=\"1\"><img src=\"$skinpath/coin03.gif\" border=\"0\"></td>
</tr>
</table>
";
'
	);


?>
