<?php

session_name("wallid");
header ("Content-type: image/png");

include("inc/lang.php");
include("strings.php");
include("inc/dbconnect.php");
include("inc/skinLib.php");
include("inc/preloads.php");
include("inc/layout.php");
include("pagetop.php");
include("inc/page.php");
include("inc/table_names.php");
include("inc/dtc_functions.php");
include("inc/submit_to_sql.php");
include("inc/dtc_tree_menu.php");

if( !isRandomNum($_REQUEST["randomwallid"]) ){
        die("Incorrect url format!!!");
}
$q = "SELECT * FROM validate_url WHERE random_val='".$_REQUEST["randomwallid"]."';";
$r = mysql_query($q)or die("Cannot query \"$q\" line: ".__LINE__." file: ".__FILE__." server said: ".mysql_error());
$n = mysql_num_rows($r);
if($n != 1)     die("Cannot found given message randomwallid in database!!!");
$a = mysql_fetch_array($r);

// seed with microseconds
function make_seed(){
	list($usec, $sec) = explode(' ', microtime());
	return (float) $sec + ((float) $usec * 100000);
}

mt_srand(make_seed());
$rand = mt_rand(0,999999);

$q = "UPDATE validate_url SET random_num='$rand' WHERE random_val='".$_REQUEST["randomwallid"]."';";
$r = mysql_query($q)or die("Cannot query \"$q\" line: ".__LINE__." file: ".__FILE__." server said: ".mysql_error());

$width = 220;
$height = 60;

$im = imagecreate ($width, $height) or die ("Cannot Initialize new GD image stream");
$lightblue_color = ImageColorAllocate ($im, 210, 210, 235);
$black = ImageColorAllocate ($im, 0, 0, 0);

$fontID = imageloadfont("/www/almosnow.gdf");
ImageString ($im, $fontID, 30, 7,$rand, $black);

$im2 = imagecreate ($width, $height) or die ("Cannot Initialize new GD image stream");
$lightblue_color2 = ImageColorAllocate ($im2, 210, 210, 235);
$black2 = ImageColorAllocate ($im2, 0, 0, 0);
if(!ImageCopy( $im2, $im, 0, 0, 0, 0, $widht-1, $height-1))
	die("Error white copy.");
for($i=0;$i<$height;$i++){
	ImageCopy( $im2, $im, 0, $i, 0, $i, $widht-2, 2);

//	ImageLine( $im, 0  , $i, $width-2 , $i, $black);
//	ImageLine( $im, $i+2, 0, $i+2,$height, $black);
//	ImageLine( $im, $i+4, 0, $i+4,$height, $black);
//	ImageLine( $im, $i+6, 0, $i+6,$height, $black);
//	ImageLine( $im, $i+8, 0, $i+8,$height, $black);
}

ImagePng ($im2);
ImageDestroy($im);
ImageDestroy($im2);



?>