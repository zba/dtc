<?php

function isMailPassword($pass){
        $reg = '^([<>()\\\/\?_\[;,;:%\^@"!a-zA-Z0-9-]){4,16}$';
        if(!ereg($reg,$pass))   return false;
        else                    return true;
}

if(isMailPassword("qsd?pof^ui!-_()%"))
	echo "true";
else
	echo "false";

?>