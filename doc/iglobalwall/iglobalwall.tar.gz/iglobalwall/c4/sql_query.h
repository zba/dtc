//#ifdef cplusplus
//extern "C" {

void do_ze_mysql_connect();
void mysql_cleanUp();
char* isInWhitelist(char* igw_login,char* pop3_username,char* pop3_server,char* fromFeild);
void testQuery();

//}
//#endif
