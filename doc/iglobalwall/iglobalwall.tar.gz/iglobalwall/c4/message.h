#ifndef __MESSAGE_H__
#define __MESSAGE_H__

#ifndef __HEADER_H__
#include "header.h"
#endif

#define STDIN_BUFFSIZE 1024

typedef struct{
// all the message (header + core)
	char* m_message;
	header* m_head;
	unsigned long m_size;

}tMsg;
char* readMessage(tMsg* msg);
tErr initMessage(tMsg* msg);
tErr readStdinUntilHeader(tMsg* msg);
void destroyMessage(tMsg* msg);

#endif // __MESSAGE_H__
