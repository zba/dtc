#define debug 1
#ifdef debug
#define LOG(a) {debugLog(a);printf("%s",a);}
#else
#define LOG(a) {}
#endif

void debugLog(char* logLine);
