char* addSlashes(char* buf,long bufSize);
char* extractMailFromString(char* field);
