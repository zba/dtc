#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <sys/types.h>
#include <pwd.h>
#include <sys/time.h>
#include <fcntl.h>

#define BUFSIZE 1024

int main(int argc,char* argv[]){
	FILE* f1,*f2;
//	int n;
//	char buf[BUFSIZE];
	int c;
	int d=0;
	f2 = fopen("/root/aaa","w");
	if(f2 == NULL)
		printf("error opening files\n");
	while( (c = getchar()) != EOF){
		fprintf(f2,"%c",c);
	}
	fclose(f2);
	return 0;
}
