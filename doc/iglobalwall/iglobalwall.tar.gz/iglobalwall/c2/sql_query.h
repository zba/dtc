//#ifdef cplusplus
//extern "C" {

void do_ze_mysql_connect();
void mysql_cleanUp();
char* findRetrivedMailbox(char** igw_login,char* pop3_username,char* pop3_server);
char* getCustomBounceMessage(char* igw_login,char* mailbox);
char* isInWhitelist(char* igw_login,char* mailBoxname,char* from_domain,char* from_user);
void saveMessageToSql(char* random_val,char* igw_login,
	char* mailbox,char* message,char* subject,char* frombox);
char* isInTolist(char* igw_login,char* mailBoxname,char* addr);
void testQuery();

//}
//#endif
