void read_config_file();
DOTCONF_CB(cb_mysql_hostname);
DOTCONF_CB(cb_mysql_user);
DOTCONF_CB(cb_mysql_pass);
DOTCONF_CB(cb_mysql_db);
DOTCONF_CB(cb_mysql_table_whitelist);
DOTCONF_CB(cb_mysql_table_pop_access);
