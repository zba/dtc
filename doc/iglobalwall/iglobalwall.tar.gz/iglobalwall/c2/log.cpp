#include <stdlib.h>
#include <stdio.h>

#include "log.h"

void debugLog(char* logLine){
	FILE* fp;

	fp = fopen("/root/debug","a+");
	fprintf(fp,"%s",logLine);
	fclose(fp);
	return;
}
