extern "C"{
/*
 * getmx()
 *
 * Get MX recs for an address.
 *
 * Upon success, it fills 'mxbuff' with one or more MX hosts, delimited by
 * ':' chars, and returns the number of hosts.  0 if none found.
 *
 */
int getmx(char *mxbuff, char *dest, int maxbuffsz);




}