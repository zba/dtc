
#define IGW_URL "http://www.iglobalwall.com/?rub=validate&randomwallid="

void bounceMessage(tMsg* msg);
