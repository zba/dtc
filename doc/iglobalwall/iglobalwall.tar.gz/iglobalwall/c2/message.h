#ifndef __MESSAGE_H__
#define __MESSAGE_H__

#ifndef __HEADER_H__
#include "header.h"
#endif

#define STDIN_BUFFSIZE 1024

class tMsg{
public:
// all the message (header + core)
	char* m_message;
	header* m_head;
	unsigned long m_size;

	tMsg(){
		m_message = NULL;
		m_head = NULL;
		m_size = 0;
	}
	~tMsg(){
		if(m_message != NULL)	free(m_message);
		if(m_head != NULL)		delete(m_head);
	}
	char* readMessage();
	tErr init();
private:
	tErr readStdinUntilHeader();
};

#endif // __MESSAGE_H__
