#ifndef __GLOBAL_H__
#define __GLOBAL_H__

// #define debug 1
// #define staticfile 1

typedef enum{
	noErr=0,
	OUT_OF_MEM=1,
	INCONSISTENT_MESSAGE=2,
	SQL_ERROR=3,
	MAILBOX_NOT_FOUND_IN_DB=4,
	FROMUSER_NOT_IN_WHITELIST=5
}tErr;

typedef struct{
	char* mysql_hostname;
	char* mysql_user;
	char* mysql_pass;
	char* mysql_db;
	char* mysql_table_whitelist;
	char* mysql_table_pop_access;
}igw_config_t;
extern igw_config_t igw_config;
int extern errno;
extern char **environ;
extern FILE* stdin;
extern FILE* stdout;
extern FILE* stderr;

#endif // __GLOBAL_H__
