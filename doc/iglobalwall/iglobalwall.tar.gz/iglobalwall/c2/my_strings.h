char* addSlashes(char* buf,long bufSize);
char* extractMailFromString(char* field);
char** getAllEmailsFromString(char* search,long* num_msg);
int isToInRcpts(char* addr,char** addrs,long nbr_addrs);
char* lf2crlf(char* buf,unsigned long* bufSize);
char* str_replace(char* buffer,char* search,char* replace);
char* str2lower(char* string);
